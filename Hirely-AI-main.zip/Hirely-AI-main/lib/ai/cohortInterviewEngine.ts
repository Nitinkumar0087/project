import fs from 'fs';
import path from 'path';
import { getGeminiClient } from './geminiClient.js';
import { curriculumData } from '../../src/data/curriculumData.js';
import { candidatesData } from '../../src/data/candidatesData.js';
import {
  Candidate,
  Curriculum,
  CurriculumDay,
  Feedback,
  FinalReport,
  InterviewResponse,
  SessionState,
} from '../../src/types.js';

// In-Memory Storage for Active Interview Sessions
const sessionsMap = new Map<string, SessionState>();

/**
 * Detects if a candidate response expresses uncertainty, lack of knowledge, or a desire to skip/pass.
 */
export function isUncertainResponse(text: string): boolean {
  if (!text) return false;
  const clean = text.toLowerCase().trim();
  const uncertainPhrases = [
    "don't know",
    "dont know",
    "do not know",
    "no idea",
    "not sure",
    "not really sure",
    "i'm not sure",
    "im not sure",
    "cannot answer",
    "can't answer",
    "cant answer",
    "skip",
    "don't have experience",
    "dont have experience",
    "no experience",
    "not familiar",
    "no clue",
    "idk",
    "pass",
    "haven't worked with",
    "havent worked with",
    "i do not know",
    "i don't recall",
    "dunno",
    "unable to answer",
    "i cannot",
    "i can't",
    "don't understand",
  ];
  return uncertainPhrases.some((phrase) => clean.includes(phrase));
}

// Helper to load curriculum dataset safely
function getCurriculumData(): Curriculum {
  try {
    const filePath = path.join(process.cwd(), 'src/data/curriculum.json');
    if (fs.existsSync(filePath)) {
      const raw = fs.readFileSync(filePath, 'utf-8');
      return JSON.parse(raw) as Curriculum;
    }
  } catch (err) {
    console.warn('fs read failed for curriculum.json, using fallback data:', err);
  }
  return curriculumData;
}

// Helper to load default candidates list safely
export function getCandidatesData(): Candidate[] {
  try {
    const filePath = path.join(process.cwd(), 'src/data/candidates.json');
    if (fs.existsSync(filePath)) {
      const raw = fs.readFileSync(filePath, 'utf-8');
      return JSON.parse(raw) as Candidate[];
    }
  } catch (err) {
    console.warn('fs read failed for candidates.json, using fallback data:', err);
  }
  return candidatesData;
}

// Get all available curriculum days as a flat list
function getAllCurriculumDays(): CurriculumDay[] {
  const curriculum = getCurriculumData();
  const allDays: CurriculumDay[] = [];
  for (const mod of curriculum.modules) {
    for (const d of mod.days) {
      allDays.push(d);
    }
  }
  return allDays;
}

// Find curriculum day details by day number
function getCurriculumDayByNumber(dayNum: number): CurriculumDay | undefined {
  const days = getAllCurriculumDays();
  return days.find((d) => d.day === dayNum);
}

/**
 * Main handler for POST /api/interview
 */
export async function handleCohortInterviewRequest(
  sessionId: string,
  candidatePayload?: Candidate,
  userMessage?: string
): Promise<InterviewResponse> {
  if (!sessionId) {
    throw new Error('sessionId is required for POST /api/interview');
  }

  let session = sessionsMap.get(sessionId);

  // --- 1. Initial Request Setup ---
  if (!session) {
    if (!candidatePayload) {
      // Fallback if no candidate passed on first request: pick first candidate from candidates.json
      const candidates = getCandidatesData();
      candidatePayload = candidates[0];
    }

    // Determine candidate starting difficulty based on experience/metrics
    let initialDifficulty: 'Easy' | 'Medium' | 'Hard' = 'Medium';
    if (candidatePayload.yearsExperience >= 5 || candidatePayload.missionsFirstTry > 25) {
      initialDifficulty = 'Hard';
    } else if (candidatePayload.yearsExperience <= 1 && candidatePayload.missionsCompleted < 15) {
      initialDifficulty = 'Easy';
    }

    session = {
      sessionId,
      candidate: candidatePayload,
      questionsAsked: 0,
      curriculumDaysCovered: [],
      topicsCovered: [],
      conversationHistory: [],
      difficulty: initialDifficulty,
      followUpCount: 0,
      scoreSignals: {
        totalTechnicalScore: 0,
        totalCommunicationScore: 0,
        evaluationsCount: 0,
      },
      interviewComplete: false,
    };

    sessionsMap.set(sessionId, session);
  } else if (candidatePayload) {
    // Update candidate if provided
    session.candidate = candidatePayload;
  }

  // --- Check if session is already completed ---
  if (session.interviewComplete) {
    return {
      reply: 'Thank you for your time. The interview is complete. We will now generate your evaluation report.',
      done: true,
      feedback: session.finalFeedback || {
        summary: 'Interview was completed previously.',
        strengths: ['Interview completed'],
        gaps: [],
        next: ['Review past sessions'],
      },
      report: session.finalReport,
    };
  }

  // --- 2. Record Candidate's Spoken / Typed Answer if subsequent message ---
  let isLatestUncertain = false;
  if (userMessage && userMessage.trim().length > 0 && session.questionsAsked > 0) {
    isLatestUncertain = isUncertainResponse(userMessage);
    session.conversationHistory.push({
      role: 'candidate',
      content: userMessage.trim(),
      wasUncertain: isLatestUncertain,
    });

    if (isLatestUncertain) {
      // Candidate indicated they don't know / skip: reset follow-up count to force topic change
      session.followUpCount = 99;
    }
  }

  // --- 3. Check Termination Guarantees ---
  // Mandatory: questionsAsked >= 8 AND curriculumDaysCovered >= 4 AND user provided at least 1 answer
  const MIN_QUESTIONS = 8;
  const MIN_CURRICULUM_DAYS = 4;

  const hasAnsweredCurrent =
    session.conversationHistory.length > 0 &&
    session.conversationHistory[session.conversationHistory.length - 1].role === 'candidate';

  if (
    session.questionsAsked >= MIN_QUESTIONS &&
    session.curriculumDaysCovered.length >= MIN_CURRICULUM_DAYS &&
    hasAnsweredCurrent
  ) {
    // Generate final structured feedback and evidence-based report
    const { feedback, report } = await generateFinalStructuredFeedbackAndReport(session);
    session.interviewComplete = true;
    session.finalFeedback = feedback;
    session.finalReport = report;

    return {
      reply: 'Thank you for your time. The interview is complete. We will now generate your evaluation report.',
      done: true,
      feedback,
      report,
    };
  }

  // --- 4. Decide Next Curriculum Day & Topic ---
  const candidate = session.candidate;
  const allDays = getAllCurriculumDays();

  // Select next day to cover
  let targetDay: CurriculumDay;
  let isFollowUp = false;

  // Check if we should do a follow-up on the current topic or pick a new curriculum day
  if (
    session.currentDayNumber &&
    session.followUpCount < 2 &&
    session.questionsAsked > 0 &&
    hasAnsweredCurrent &&
    !isLatestUncertain
  ) {
    // Stay on current day for an adaptive follow-up (deeper probe or clarification)
    targetDay = getCurriculumDayByNumber(session.currentDayNumber) || allDays[0];
    session.followUpCount += 1;
    isFollowUp = true;
  } else {
    // Move to a new unvisited curriculum day to ensure 4 distinct days coverage and avoid repeating unknown topics
    session.followUpCount = 0;
    isFollowUp = false;

    // Prioritize days from candidate's completed/failed missions or unvisited days
    const unvisitedDays = allDays.filter((d) => !session.curriculumDaysCovered.includes(d.day));

    // Prefer candidate's completed missions or failed missions first for diagnostic relevance
    const completedDayNums = candidate.completedMissions.map((m) => m.day);
    const failedDayNums = candidate.failedMissions.map((m) => m.day);

    let candidatePreferredUnvisited = unvisitedDays.filter(
      (d) => completedDayNums.includes(d.day) || failedDayNums.includes(d.day)
    );

    if (candidatePreferredUnvisited.length > 0) {
      targetDay = candidatePreferredUnvisited[Math.floor(Math.random() * candidatePreferredUnvisited.length)];
    } else if (unvisitedDays.length > 0) {
      targetDay = unvisitedDays[0];
    } else {
      // If all days visited, pick next in line
      targetDay = allDays[session.questionsAsked % allDays.length];
    }
  }

  // Update session day tracking
  session.currentDayNumber = targetDay.day;
  session.currentTopic = targetDay.topic;

  if (!session.curriculumDaysCovered.includes(targetDay.day)) {
    session.curriculumDaysCovered.push(targetDay.day);
  }
  if (!session.topicsCovered.includes(targetDay.topic)) {
    session.topicsCovered.push(targetDay.topic);
  }

  // --- 5. Generate Question using Gemini ---
  const ai = getGeminiClient();

  // Extract previously asked interviewer questions to prevent repetition
  const previousInterviewerQuestions = session.conversationHistory
    .filter((m) => m.role === 'interviewer')
    .map((m, idx) => `Question ${idx + 1}: ${m.content}`)
    .join('\n');

  // Build personalization context summary
  const completedTopicsList = candidate.completedMissions.map((m) => `Day ${m.day}: ${m.topic} (${m.attempts} attempt(s))`).join(', ');
  const failedTopicsList = candidate.failedMissions.map((m) => `Day ${m.day}: ${m.topic} (Error: ${m.lastError || 'Failed'})`).join(', ');
  const skippedTopicsList = candidate.skippedMissions.map((m) => `Day ${m.day}: ${m.topic}`).join(', ');

  const prompt = `You are Hirely AI, a professional senior HR and technical interviewer conducting a live interview for a 31-Day AI Engineering Cohort.

CANDIDATE PROFILE:
- Name: ${candidate.name}
- Job Role: ${candidate.jobRole} (${candidate.yearsExperience} years exp, ${candidate.education})
- Cohort Activity: ${candidate.commitDays} commit days, ${candidate.missionsCompleted} missions completed.
- Capstone Project: ${candidate.capstoneProject || 'None specified'}
- Completed Topics: ${completedTopicsList || 'None'}
- Failed Topics: ${failedTopicsList || 'None'}
- Skipped Topics: ${skippedTopicsList || 'None'}

INTERVIEW PROGRESS:
- Current Question Number: ${session.questionsAsked + 1}
- Selected Target Topic: Day ${targetDay.day} - ${targetDay.topic}
- Target Topic Objectives: ${targetDay.learningObjectives.join('; ')}
- Target Topic Tools: ${targetDay.tools.join(', ')}
- Candidate's Previous Response Was Uncertain/Skip? ${isLatestUncertain ? 'YES' : 'NO'}
- Is this an adaptive follow-up? ${isFollowUp ? 'YES' : 'NO'}

PREVIOUS INTERVIEWER QUESTIONS ASKED IN THIS SESSION (NEVER REPEAT ANY OF THESE):
${previousInterviewerQuestions || '(First question of the interview)'}

CONVERSATION TRANSCRIPT SO FAR:
${
  session.conversationHistory.length > 0
    ? session.conversationHistory.map((m) => `${m.role.toUpperCase()}: ${m.content}`).join('\n\n')
    : '(This is the first question of the interview)'
}

INTERVIEWER GUIDELINES:
1. Act like a real human HR/Technical interviewer — warm, professional, encouraging, and direct.
2. ABSOLUTE RULE: NEVER repeat or re-ask any question that was previously asked above.
3. ${
    isLatestUncertain
      ? `The candidate indicated they do not know, are unsure, or wish to skip the previous topic. Do NOT press them or repeat that question. Start with a natural human acknowledgment (e.g., "That's completely fine! Let's move on to our next topic.") and ask a new question on Day ${targetDay.day}: ${targetDay.topic}.`
      : isFollowUp
      ? `The candidate gave a response to the previous question. Evaluate their answer in context: if partially correct, ask a deeper follow-up probing how they implemented or verified it; if too short, ask for a concrete example or clarification.`
      : `Ask a clean, clear technical or system-design question focused on Day ${targetDay.day}: ${targetDay.topic}.`
  }
4. Keep the question concise, natural, and conversational for spoken voice (2-3 sentences max).
5. Output ONLY the spoken question text. Do NOT output JSON, code blocks, or meta-commentary.`;

  let replyText = '';
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction:
          'You are Hirely AI, a professional, human-like HR and technical interviewer. Never repeat questions. Output spoken dialogue only.',
        temperature: 0.7,
        maxOutputTokens: 250,
      },
    });

    replyText = response.text?.trim() || `Could you explain the core concepts of ${targetDay.topic} and how you applied them in your work?`;
  } catch (err: any) {
    console.error('Gemini error generating question:', err);
    if (isLatestUncertain) {
      replyText = `That's completely fine. Let's move on. How would you approach Day ${targetDay.day}: ${targetDay.topic} using tools like ${targetDay.tools.join(', ')}?`;
    } else {
      replyText = `Let's discuss Day ${targetDay.day}: ${targetDay.topic}. What are the primary trade-offs and design considerations when working with ${targetDay.tools.join(', ')}?`;
    }
  }

  // Record interviewer turn
  session.questionsAsked += 1;
  session.conversationHistory.push({
    role: 'interviewer',
    content: replyText,
    dayNumber: targetDay.day,
    topic: targetDay.topic,
  });

  return {
    reply: replyText,
    done: false,
  };
}

/**
 * Generate Truthful, Evidence-Based Structured Feedback and Final Report using Gemini
 */
async function generateFinalStructuredFeedbackAndReport(
  session: SessionState
): Promise<{ feedback: Feedback; report: FinalReport }> {
  const ai = getGeminiClient();
  const candidate = session.candidate;

  const prompt = `You are a senior hiring director and AI cohort manager evaluating a completed technical interview for ${candidate.name}.

CANDIDATE BACKGROUND & RESUME:
- Name: ${candidate.name}
- Job Role: ${candidate.jobRole} (${candidate.yearsExperience} years exp, ${candidate.education})
- Capstone Project: ${candidate.capstoneProject || 'None specified'}
- Cohort Metrics: ${candidate.missionsCompleted} completed missions, ${candidate.commitDays} commit days.

COMPLETE INTERVIEW TRANSCRIPT:
${session.conversationHistory.map((m) => `${m.role.toUpperCase()}: ${m.content}`).join('\n\n')}

CURRICULUM DAYS COVERED: Days [${session.curriculumDaysCovered.join(', ')}]
TOPICS COVERED: ${session.topicsCovered.join(', ')}

EVALUATION RULES (STRICT ANTI-HALLUCINATION & EVIDENCE-BASED):
1. Base your evaluation ONLY on candidate's actual answers in the transcript and candidate profile.
2. NEVER invent skills, projects, experience, or achievements not demonstrated in the transcript.
3. If a skill or topic was not tested or lacks evidence in the transcript, write: "Not enough evidence from the interview to evaluate this skill."
4. If candidate said "I don't know" or skipped a question, mark that specific topic as unanswered with a low score, but DO NOT unfairly assume lack of general problem-solving or communication across unrelated areas.
5. Provide EVIDENCE strings for scores referencing specific candidate statements in the transcript.
6. Determine Evidence-Based Confidence Level: "High" (5+ detailed responses), "Medium" (3-4 responses), or "Low" (mostly brief/skipped).

Return strict JSON matching this schema:
{
  "overallScore": number (0-100),
  "confidenceLevel": "High" | "Medium" | "Low",
  "evidenceSummary": "Grounding summary citing actual transcript evidence",
  "categoryScores": {
    "technicalKnowledge": number (0-100),
    "communication": number (0-100),
    "relevance": number (0-100),
    "completeness": number (0-100),
    "problemSolving": number (0-100),
    "answerStructure": number (0-100)
  },
  "categoryEvidence": {
    "technicalKnowledge": "Transcript evidence",
    "communication": "Transcript evidence",
    "relevance": "Transcript evidence",
    "completeness": "Transcript evidence",
    "problemSolving": "Transcript evidence",
    "answerStructure": "Transcript evidence"
  },
  "strengths": ["Demonstrated strength supported by transcript evidence", "Another demonstrated strength"],
  "gaps": ["Observed weakness or skipped topic in transcript", "Area needing study"],
  "next": ["Actionable curriculum recommendation 1", "Actionable project step 2"],
  "overallFeedback": "2-3 sentence executive evaluation grounded in actual transcript performance.",
  "roleSuitability": "Strong Hire | Hire | Needs Practice | Below Threshold",
  "questionSummaries": [
    {
      "questionNumber": 1,
      "question": "Question text asked",
      "candidateAnswer": "Candidate actual answer text",
      "score": number (0-10),
      "feedback": "Truthful feedback referencing transcript evidence"
    }
  ]
}`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction:
          'You are a fair, precise hiring director generating an evidence-based, anti-hallucination interview evaluation report. Output strict JSON only.',
        responseMimeType: 'application/json',
        temperature: 0.2,
      },
    });

    const parsed = JSON.parse(response.text || '{}');

    const feedback: Feedback = {
      summary:
        parsed.overallFeedback ||
        `${candidate.name} completed the interview covering ${session.curriculumDaysCovered.length} curriculum topics. Evaluation based strictly on demonstrated responses.`,
      strengths:
        Array.isArray(parsed.strengths) && parsed.strengths.length > 0
          ? parsed.strengths
          : ['Attempted technical questions directly', 'Maintained professional communication'],
      gaps:
        Array.isArray(parsed.gaps) && parsed.gaps.length > 0
          ? parsed.gaps
          : ['Could expand on edge-case architectural trade-offs'],
      next:
        Array.isArray(parsed.next) && parsed.next.length > 0
          ? parsed.next
          : ['Review cohort curriculum modules for skipped/unanswered areas'],
      confidenceLevel: parsed.confidenceLevel || 'Medium',
      evidenceSummary: parsed.evidenceSummary || 'Report synthesized from interview transcript.',
    };

    // Construct Q&A summaries from transcript if missing
    const historyCandAnswers = session.conversationHistory.filter((m) => m.role === 'candidate');
    const historyQuestions = session.conversationHistory.filter((m) => m.role === 'interviewer');

    const questionSummaries =
      Array.isArray(parsed.questionSummaries) && parsed.questionSummaries.length > 0
        ? parsed.questionSummaries
        : historyQuestions.map((q, idx) => {
            const ans = historyCandAnswers[idx]?.content || '(No response provided)';
            const isUncertain = isUncertainResponse(ans);
            return {
              questionNumber: idx + 1,
              question: q.content,
              candidateAnswer: ans,
              score: isUncertain ? 3 : 7,
              feedback: isUncertain
                ? 'Candidate passed on this question ("I don\'t know"). Question marked as unanswered.'
                : 'Candidate answered question in interview.',
            };
          });

    const report: FinalReport = {
      overallScore: Math.min(100, Math.max(0, Math.round(parsed.overallScore ?? 75))),
      categoryScores: {
        technicalKnowledge: Math.min(100, Math.max(0, Math.round(parsed.categoryScores?.technicalKnowledge ?? 70))),
        communication: Math.min(100, Math.max(0, Math.round(parsed.categoryScores?.communication ?? 75))),
        relevance: Math.min(100, Math.max(0, Math.round(parsed.categoryScores?.relevance ?? 75))),
        completeness: Math.min(100, Math.max(0, Math.round(parsed.categoryScores?.completeness ?? 65))),
        problemSolving: Math.min(100, Math.max(0, Math.round(parsed.categoryScores?.problemSolving ?? 70))),
        answerStructure: Math.min(100, Math.max(0, Math.round(parsed.categoryScores?.answerStructure ?? 70))),
      },
      strengths: feedback.strengths,
      areasToImprove: feedback.gaps,
      overallFeedback: feedback.summary,
      roleSuitability: parsed.roleSuitability || 'Needs Practice',
      questionSummaries,
      confidenceLevel: feedback.confidenceLevel,
      evidenceSummary: feedback.evidenceSummary,
      categoryEvidence: parsed.categoryEvidence,
    };

    return { feedback, report };
  } catch (err) {
    console.error('Error generating structured feedback and report:', err);

    // Fallback grounded in transcript facts
    const candMsgs = session.conversationHistory.filter((m) => m.role === 'candidate');
    const totalMsgs = candMsgs.length;
    const uncertainCount = candMsgs.filter((m) => isUncertainResponse(m.content)).length;
    const answeredCount = totalMsgs - uncertainCount;

    const fallbackScore = Math.min(90, Math.max(30, Math.round((answeredCount / (totalMsgs || 1)) * 80)));

    const feedback: Feedback = {
      summary: `${candidate.name} completed ${session.questionsAsked} questions across ${session.curriculumDaysCovered.length} cohort modules. Answered ${answeredCount} topic(s) and skipped/indicated uncertainty on ${uncertainCount} topic(s).`,
      strengths: [
        'Engaged with AI interviewer across multiple curriculum modules',
        'Transparent regarding areas of missing knowledge',
      ],
      gaps: uncertainCount > 0 ? [`Skipped or expressed uncertainty on ${uncertainCount} interview question(s)`] : ['Provide deeper architectural trade-offs'],
      next: ['Review curriculum modules for skipped questions', 'Practice explaining technical trade-offs'],
      confidenceLevel: totalMsgs > 5 ? 'High' : 'Medium',
      evidenceSummary: `Evaluated ${totalMsgs} candidate responses from interview transcript.`,
    };

    const report: FinalReport = {
      overallScore: fallbackScore,
      categoryScores: {
        technicalKnowledge: fallbackScore,
        communication: 75,
        relevance: 75,
        completeness: Math.round((answeredCount / (totalMsgs || 1)) * 100),
        problemSolving: fallbackScore,
        answerStructure: 70,
      },
      strengths: feedback.strengths,
      areasToImprove: feedback.gaps,
      overallFeedback: feedback.summary,
      roleSuitability: fallbackScore >= 75 ? 'Hire' : 'Needs Practice',
      questionSummaries: session.conversationHistory
        .filter((m) => m.role === 'interviewer')
        .map((q, idx) => {
          const ans = candMsgs[idx]?.content || '(No response provided)';
          const isUncert = isUncertainResponse(ans);
          return {
            questionNumber: idx + 1,
            question: q.content,
            candidateAnswer: ans,
            score: isUncert ? 3 : 7,
            feedback: isUncert
              ? 'Candidate indicated uncertainty or skipped question.'
              : 'Candidate provided answer during interview session.',
          };
        }),
      confidenceLevel: feedback.confidenceLevel,
      evidenceSummary: feedback.evidenceSummary,
    };

    return { feedback, report };
  }
}

