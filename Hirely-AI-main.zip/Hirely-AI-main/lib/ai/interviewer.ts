import { Type } from '@google/genai';
import { getGeminiClient } from './geminiClient.js';
import { InterviewConfig, InterviewQAPair, QuestionItem, InterviewDifficulty } from '../../src/types.js';
import { isUncertainResponse } from './cohortInterviewEngine.js';

export const SYSTEM_INTERVIEWER_PROMPT = `
You are Hirely AI, an expert, professional, and empathetic AI interviewer conducting a live voice-based job interview.
Your goal is to evaluate the candidate fairly and naturally, acting like an experienced hiring manager.

Core Rules:
1. Conduct yourself professionally and politely, like a real human HR and technical interviewer.
2. Ask exactly ONE clear question at a time suitable for spoken audio.
3. NEVER answer your own questions or provide the solution in the question text.
4. Keep questions concise and well-suited for spoken voice output (2-3 sentences max).
5. Stay strictly relevant to the selected job role and difficulty level.
6. ABSOLUTE RULE: Never repeat or re-ask previously asked questions.
7. HANDLE UNCERTAIN RESPONSES NATURALLY:
   If the candidate says "I don't know", "not sure", "no idea", "cannot answer", "skip", or "no experience":
   - Do NOT press or repeat the same question.
   - Acknowledge warmly and naturally (e.g. "That's completely fine. Let's move on to our next topic.")
   - Move directly to a new question on a different core topic.
8. INTELLIGENT FOLLOW-UPS:
   - If answer is partially correct: ask a deeper follow-up (e.g. "Can you explain how you implemented this in your project?").
   - If answer is too short: ask for a concrete example or clarification.
   - If candidate misunderstands: rephrase or clarify gently.
9. Adapt difficulty dynamically based on candidate performance.
`;

export async function generateInitialQuestion(config: InterviewConfig): Promise<{
  introSpeech: string;
  question: QuestionItem;
}> {
  const ai = getGeminiClient();
  const roleName = config.role === 'Custom' && config.customRole ? config.customRole : config.role;

  const prompt = `
Generate the opening greeting and the FIRST interview question for a candidate applying for the role of "${roleName}" at "${config.difficulty}" difficulty level.

Output JSON format matching this schema:
{
  "introSpeech": "A short, professional 1-2 sentence welcome and brief interview framing (e.g. 'Hello! Welcome to your Hirely AI mock interview for the Software Developer position. Let's begin with our first question.')",
  "questionText": "The actual interview question to ask.",
  "interviewerNote": "Short internal context why this question is being asked.",
  "expectedKeyPoints": ["key point 1", "key point 2"]
}
`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INTERVIEWER_PROMPT,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            introSpeech: { type: Type.STRING },
            questionText: { type: Type.STRING },
            interviewerNote: { type: Type.STRING },
            expectedKeyPoints: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
          },
          required: ['introSpeech', 'questionText'],
        },
      },
    });

    const jsonText = response.text || '{}';
    const parsed = JSON.parse(jsonText);

    return {
      introSpeech: parsed.introSpeech || `Welcome to your ${roleName} interview! Let's get started.`,
      question: {
        id: `q_1_${Date.now()}`,
        index: 1,
        questionText: parsed.questionText || `Can you tell me about your background and experience as a ${roleName}?`,
        interviewerNote: parsed.interviewerNote || 'Initial baseline question',
        expectedKeyPoints: parsed.expectedKeyPoints || [],
        isFollowUp: false,
      },
    };
  } catch (err) {
    console.error('Error generating initial question:', err);
    // Bulletproof fallback
    return {
      introSpeech: `Welcome to your mock interview for the ${roleName} position. I will be your interviewer today. Let's begin.`,
      question: {
        id: `q_1_${Date.now()}`,
        index: 1,
        questionText: `To start off, could you briefly introduce yourself and share what interests you about the ${roleName} role?`,
        interviewerNote: 'Warm-up intro question',
        expectedKeyPoints: ['Relevant experience', 'Key skills', 'Motivation'],
        isFollowUp: false,
      },
    };
  }
}

export async function generateNextQuestion(
  config: InterviewConfig,
  history: InterviewQAPair[],
  currentDifficulty: InterviewDifficulty
): Promise<{
  question: QuestionItem;
  nextDifficulty: InterviewDifficulty;
  transitionMessage?: string;
}> {
  const ai = getGeminiClient();
  const roleName = config.role === 'Custom' && config.customRole ? config.customRole : config.role;
  const questionNumber = history.length + 1;

  // Format previous history for context
  const historyText = history
    .map((item, idx) => {
      const evalText = item.evaluation
        ? `[Score: ${item.evaluation.overall}/10, TechAccuracy: ${item.evaluation.technicalAccuracy}, Communication: ${item.evaluation.communication}] Feedback: ${item.evaluation.feedbackSummary}`
        : 'No eval';
      return `
Q${idx + 1}: ${item.question.questionText}
Candidate Answer: "${item.candidateAnswer || '(Candidate gave a brief/blank response)'}"
Evaluation: ${evalText}
`;
    })
    .join('\n---\n');

  const lastQA = history[history.length - 1];
  const lastCandidateAnswer = lastQA?.candidateAnswer || '';
  const lastIsUncertain = isUncertainResponse(lastCandidateAnswer);
  const lastScore = lastQA?.evaluation?.overall ?? 7;

  // Build explicit list of previously asked questions to strictly forbid repeats
  const previousQuestionsList = history
    .map((h, i) => `Question ${i + 1}: ${h.question.questionText}`)
    .join('\n');

  const prompt = `
You are continuing an interview for the role of "${roleName}".
Current Question Index: ${questionNumber} of ${config.totalQuestions}.
Base Difficulty: "${config.difficulty}".
Current Adaptive Difficulty: "${currentDifficulty}".
Candidate Previous Answer Was Uncertain/Skip? ${lastIsUncertain ? 'YES' : 'NO'}

PREVIOUS INTERVIEW QUESTIONS ASKED IN THIS SESSION (STRICT RULE: NEVER REPEAT ANY OF THESE):
${previousQuestionsList || '(None yet)'}

Previous Interview Conversation & Evaluations:
${historyText}

Task:
Analyze the candidate's latest response: "${lastCandidateAnswer}"

Guidelines:
- IF CANDIDATE SAID "I DON'T KNOW", "NOT SURE", OR SKIPPED (${lastIsUncertain ? 'YES' : 'NO'}):
  Do NOT ask them to re-explain or press further on that topic.
  Acknowledge warmly and naturally in transitionMessage (e.g. "That's completely fine. Let's move on to another topic.")
  Set isFollowUp: false, and ask a new question on a completely DIFFERENT core skill for the ${roleName} role.
- IF CANDIDATE GAVE A PARTIAL ANSWER:
  Ask an intelligent FOLLOW-UP question probing how they implemented it or asking for a specific example.
- IF CANDIDATE ANSWER WAS TOO BRIEF:
  Ask for clarification or a concrete scenario.
- NEVER repeat any previously asked question.
- Keep the question concise (2-3 sentences) for spoken audio output.

JSON Response Schema:
{
  "transitionMessage": "Short 1-sentence transition (e.g. 'That\\'s completely fine. Let\\'s move on to our next question.')",
  "questionText": "The next question or follow-up question to ask",
  "isFollowUp": true or false,
  "interviewerNote": "Reason for asking this question",
  "expectedKeyPoints": ["point 1", "point 2"],
  "suggestedDifficulty": "Easy" | "Medium" | "Hard"
}
`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INTERVIEWER_PROMPT,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            transitionMessage: { type: Type.STRING },
            questionText: { type: Type.STRING },
            isFollowUp: { type: Type.BOOLEAN },
            interviewerNote: { type: Type.STRING },
            expectedKeyPoints: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            suggestedDifficulty: { type: Type.STRING },
          },
          required: ['questionText', 'isFollowUp'],
        },
      },
    });

    const jsonText = response.text || '{}';
    const parsed = JSON.parse(jsonText);

    let nextDiff: InterviewDifficulty = currentDifficulty;
    if (parsed.suggestedDifficulty === 'Easy' || parsed.suggestedDifficulty === 'Medium' || parsed.suggestedDifficulty === 'Hard') {
      nextDiff = parsed.suggestedDifficulty;
    } else if (lastScore >= 8 && currentDifficulty === 'Easy') {
      nextDiff = 'Medium';
    } else if (lastScore >= 9 && currentDifficulty === 'Medium') {
      nextDiff = 'Hard';
    } else if (lastScore <= 4 && currentDifficulty === 'Hard') {
      nextDiff = 'Medium';
    } else if (lastScore <= 3 && currentDifficulty === 'Medium') {
      nextDiff = 'Easy';
    }

    const transitionMsg = lastIsUncertain
      ? parsed.transitionMessage || "That's completely fine. Let's move on to our next question."
      : parsed.transitionMessage || undefined;

    return {
      transitionMessage: transitionMsg,
      question: {
        id: `q_${questionNumber}_${Date.now()}`,
        index: questionNumber,
        questionText: parsed.questionText,
        interviewerNote: parsed.interviewerNote || 'Adaptive question',
        expectedKeyPoints: parsed.expectedKeyPoints || [],
        isFollowUp: lastIsUncertain ? false : Boolean(parsed.isFollowUp),
      },
      nextDifficulty: nextDiff,
    };
  } catch (err) {
    console.error('Error generating next question:', err);
    // Fallback based on question number
    return {
      transitionMessage: lastIsUncertain
        ? "No problem at all. Let's continue with our next topic."
        : "Thank you for sharing that.",
      question: {
        id: `q_${questionNumber}_${Date.now()}`,
        index: questionNumber,
        questionText: `Can you describe a key system design or problem-solving challenge you faced as a ${roleName} and how you approached it?`,
        interviewerNote: 'Fallback adaptive question',
        expectedKeyPoints: ['Problem context', 'Implementation strategy', 'Outcomes'],
        isFollowUp: false,
      },
      nextDifficulty: currentDifficulty,
    };
  }
}

