import type { VercelRequest, VercelResponse } from '@vercel/node';
import { getCandidatesData } from '../lib/ai/cohortInterviewEngine.js';

export default function handler(req: VercelRequest, res: VercelResponse) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  try {
    const candidates = getCandidatesData();
    res.setHeader('Content-Type', 'application/json');
    return res.status(200).json(candidates);
  } catch (err: any) {
    console.error('Error fetching candidates in serverless function:', err);
    return res.status(500).json({ error: 'Failed to load candidates.' });
  }
}
