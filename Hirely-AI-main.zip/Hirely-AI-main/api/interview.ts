import type { VercelRequest, VercelResponse } from '@vercel/node';
import { handleCohortInterviewRequest } from '../lib/ai/cohortInterviewEngine.js';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body || {};
    const { sessionId, candidate, message } = body;

    if (!sessionId) {
      return res.status(400).json({ error: 'sessionId is required.' });
    }

    const result = await handleCohortInterviewRequest(sessionId, candidate, message);
    res.setHeader('Content-Type', 'application/json');
    return res.status(200).json(result);
  } catch (err: any) {
    console.error('Error handling POST /api/interview in serverless function:', err);
    return res.status(500).json({
      reply: 'An error occurred processing your request.',
      done: false,
      error: err.message || 'Internal server error',
    });
  }
}
