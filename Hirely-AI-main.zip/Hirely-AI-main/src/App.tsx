import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { LandingPage } from './components/LandingPage';
import { InterviewSetup } from './components/InterviewSetup';
import { InterviewRoom } from './components/InterviewRoom';
import { InterviewReport } from './components/InterviewReport';
import { Candidate, FinalReport, InterviewConfig, InterviewPhase, InterviewRole } from './types';

export default function App() {
  const [phase, setPhase] = useState<InterviewPhase>('landing');
  const [selectedRole, setSelectedRole] = useState<InterviewRole>('Software Developer');
  const [selectedCandidate, setSelectedCandidate] = useState<Candidate | undefined>(undefined);
  const [interviewConfig, setInterviewConfig] = useState<InterviewConfig>({
    role: 'Software Developer',
    difficulty: 'Medium',
    durationMinutes: 20,
    totalQuestions: 8,
  });
  const [finalReport, setFinalReport] = useState<FinalReport | null>(null);

  const handleStartSetup = (role?: InterviewRole) => {
    if (role) {
      setSelectedRole(role);
      setInterviewConfig((prev) => ({ ...prev, role }));
    }
    setPhase('setup');
  };

  const handleStartInterview = (config: InterviewConfig, cand?: Candidate) => {
    setInterviewConfig(config);
    setSelectedCandidate(cand);
    setPhase('interview');
  };

  const handleFinishInterview = (report: FinalReport) => {
    setFinalReport(report);
    setPhase('report');
  };

  const handleReset = () => {
    setPhase('landing');
    setFinalReport(null);
  };

  return (
    <div className="min-h-screen bg-slate-950 font-sans text-slate-100 antialiased selection:bg-indigo-500 selection:text-white">
      <Navbar
        currentPhase={phase}
        onNavigate={(targetPhase) => {
          if (targetPhase === 'setup') {
            setPhase('setup');
          } else {
            handleReset();
          }
        }}
        onReset={handleReset}
      />

      <main>
        {phase === 'landing' && (
          <LandingPage onStartSetup={handleStartSetup} />
        )}

        {phase === 'setup' && (
          <InterviewSetup
            initialRole={selectedRole}
            onStartInterview={handleStartInterview}
            onCancel={handleReset}
          />
        )}

        {phase === 'interview' && (
          <InterviewRoom
            config={interviewConfig}
            selectedCandidate={selectedCandidate}
            onFinishInterview={handleFinishInterview}
            onExit={handleReset}
          />
        )}

        {phase === 'report' && finalReport && (
          <InterviewReport
            report={finalReport}
            config={interviewConfig}
            onRetake={() => setPhase('setup')}
            onHome={handleReset}
          />
        )}
      </main>
    </div>
  );
}

