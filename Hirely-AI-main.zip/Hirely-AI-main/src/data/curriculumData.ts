import { Curriculum } from '../types.js';

export const curriculumData: Curriculum = {
  "cohort": "31-Day AI Engineer Cohort",
  "modules": [
    {
      "id": 1,
      "name": "Foundations of LLMs & Prompting",
      "days": [
        {
          "day": 1,
          "topic": "LLM Architectures & Tokenization",
          "learningObjectives": ["Understand transformer decoder-only models", "BPE tokenization", "Context window constraints"],
          "tools": ["Tiktoken", "HuggingFace Transformers"]
        },
        {
          "day": 2,
          "topic": "Advanced Prompt Engineering & System Instructions",
          "learningObjectives": ["Few-shot prompting", "Chain-of-Thought (CoT)", "Role-based system prompts"],
          "tools": ["Gemini API", "OpenAI API"]
        },
        {
          "day": 3,
          "topic": "Structured Outputs & JSON Schema Guarantees",
          "learningObjectives": ["Pydantic validation", "JSON schema enforcement", "Function calling signatures"],
          "tools": ["Google GenAI SDK", "Zod"]
        },
        {
          "day": 4,
          "topic": "Tool Use & Function Calling",
          "learningObjectives": ["Binding tools to LLM sessions", "Handling multi-turn tool calling loops", "Error recovery"],
          "tools": ["Gemini Tools API", "LangChain Tools"]
        }
      ]
    },
    {
      "id": 2,
      "name": "Embeddings & Vector Databases",
      "days": [
        {
          "day": 5,
          "topic": "Vector Embeddings & Distance Metrics",
          "learningObjectives": ["Cosine similarity", "Dot product vs Euclidean distance", "High-dimensional vector spaces"],
          "tools": ["text-embedding-004", "NumPy"]
        },
        {
          "day": 6,
          "topic": "Vector Databases & Indexing Strategies",
          "learningObjectives": ["HNSW vs IVF indexes", "Vector database CRUD operations", "Metadata filtering"],
          "tools": ["ChromaDB", "Pinecone", "Qdrant"]
        },
        {
          "day": 7,
          "topic": "Chunking Strategies & Document Ingestion",
          "learningObjectives": ["Semantic chunking", "Overlapping sliding windows", "Handling PDF/Markdown ingestion"],
          "tools": ["LangChain Text Splitters", "LlamaIndex"]
        },
        {
          "day": 8,
          "topic": "Hybrid Search & Re-ranking",
          "learningObjectives": ["BM25 sparse search", "Dense vector search fusion", "Cross-encoder re-rankers"],
          "tools": ["Cohere Rerank", "Pinecone Hybrid Search"]
        }
      ]
    },
    {
      "id": 3,
      "name": "Retrieval-Augmented Generation (RAG)",
      "days": [
        {
          "day": 9,
          "topic": "Basic RAG Pipeline Architecture",
          "learningObjectives": ["Retrieve-then-generate workflow", "Context window packing", "Prompt grounding"],
          "tools": ["LlamaIndex", "LangChain"]
        },
        {
          "day": 10,
          "topic": "Advanced RAG: Query Transformation & Hypothetical Document Embeddings (HyDE)",
          "learningObjectives": ["Query rewriting", "Sub-query decomposition", "HyDE generation"],
          "tools": ["Gemini API", "RAG Triad"]
        },
        {
          "day": 11,
          "topic": "Corrective RAG (CRAG) & Self-RAG",
          "learningObjectives": ["Evaluating retrieved passage relevance", "Web search fallback", "Self-reflection tokens"],
          "tools": ["Tavily API", "LangGraph"]
        },
        {
          "day": 12,
          "topic": "RAG Evaluation & Benchmarking (Ragas & TruLens)",
          "learningObjectives": ["Faithfulness metric", "Answer relevance", "Context precision & recall"],
          "tools": ["Ragas framework", "TruLens"]
        }
      ]
    },
    {
      "id": 4,
      "name": "AI Agents & Multi-Agent Workflows",
      "days": [
        {
          "day": 13,
          "topic": "ReAct Framework & Agent Memory",
          "learningObjectives": ["Reasoning and Acting loops", "Short-term vs long-term agent memory", "Scratchpad execution"],
          "tools": ["LangChain Agents", "Custom ReAct Loops"]
        },
        {
          "day": 14,
          "topic": "Stateful Agent Graphs with LangGraph / AutoGen",
          "learningObjectives": ["Directed Acyclic Graphs (DAGs) for agents", "State persistence and checkpoints", "Human-in-the-loop"],
          "tools": ["LangGraph", "AutoGen"]
        },
        {
          "day": 15,
          "topic": "Multi-Agent Collaboration & Task Delegation",
          "learningObjectives": ["Hierarchical agent teams", "Role-based agent handoffs", "Consensus protocols"],
          "tools": ["CrewAI", "AutoGen Multi-Agent"]
        },
        {
          "day": 16,
          "topic": "Agentic Evaluation & Defensive Guardrails",
          "learningObjectives": ["Infinite loop detection", "Tool call permissioning", "Input/Output guardrails"],
          "tools": ["NeMo Guardrails", "Llama Guard"]
        }
      ]
    },
    {
      "id": 5,
      "name": "Fine-Tuning & Model Alignment",
      "days": [
        {
          "day": 17,
          "topic": "Parameter-Efficient Fine-Tuning (PEFT & LoRA)",
          "learningObjectives": ["Low-Rank Adaptation mechanics", "Quantized LoRA (QLoRA)", "Dataset preparation"],
          "tools": ["HuggingFace PEFT", "Unsloth", "TRL"]
        },
        {
          "day": 18,
          "topic": "Direct Preference Optimization (DPO) & RLHF",
          "learningObjectives": ["Alignment algorithms", "Chosen vs rejected dataset formatting", "Reward modeling"],
          "tools": ["TRL DPOTrainer", "Axolotl"]
        },
        {
          "day": 19,
          "topic": "Model Quantization & Inference Optimization",
          "learningObjectives": ["GGUF, AWQ, and EXL2 formats", "KV Cache optimization", "PagedAttention"],
          "tools": ["vLLM", "Ollama", "llama.cpp"]
        }
      ]
    },
    {
      "id": 6,
      "name": "Multimodal AI & Speech Processing",
      "days": [
        {
          "day": 20,
          "topic": "Vision-Language Models (VLMs)",
          "learningObjectives": ["Image patch embeddings", "Visual Question Answering", "OCR & Document understanding"],
          "tools": ["Gemini 1.5 Flash Vision", "PaliGemma"]
        },
        {
          "day": 21,
          "topic": "Voice AI, Audio Embeddings & Realtime Speech",
          "learningObjectives": ["Whisper speech recognition", "Streaming text-to-speech", "Realtime WebSockets audio"],
          "tools": ["Whisper API", "ElevenLabs", "Gemini Live API"]
        }
      ]
    },
    {
      "id": 7,
      "name": "LLMOps, Streaming & Production Deployment",
      "days": [
        {
          "day": 22,
          "topic": "Server-Sent Events (SSE) & Real-time LLM Streaming",
          "learningObjectives": ["Streaming response chunks", "Backpressure handling", "WebSocket vs SSE in production"],
          "tools": ["Express SSE", "Vite UI Streaming"]
        },
        {
          "day": 23,
          "topic": "LLM Tracing, Observability & Cost Tracking",
          "learningObjectives": ["Span tracking", "Token usage logging", "Latency profiling"],
          "tools": ["LangSmith", "Arize Phoenix", "Helicone"]
        },
        {
          "day": 24,
          "topic": "Caching & Semantic Cache for LLM Endpoints",
          "learningObjectives": ["Exact match caching", "Semantic vector similarity cache", "Cache eviction policies"],
          "tools": ["GPTCache", "Redis Vector Store"]
        }
      ]
    },
    {
      "id": 8,
      "name": "Capstone Project & Production AI Systems",
      "days": [
        {
          "day": 25,
          "topic": "Production Security, Prompt Injection & Jailbreak Defense",
          "learningObjectives": ["Direct & indirect prompt injection", "Data exfiltration prevention", "Sandboxing code execution"],
          "tools": ["Rebuff", "Prompt Guard"]
        },
        {
          "day": 26,
          "topic": "Full-Stack AI Application Architecture",
          "learningObjectives": ["Combining Frontend, Cloud Run Server, Vector DB, and LLM APIs securely"],
          "tools": ["Docker", "Cloud Run", "FastAPI / Express"]
        },
        {
          "day": 27,
          "topic": "Capstone System Design & Architecture Review",
          "learningObjectives": ["End-to-end AI workflow orchestration", "High throughput latency tradeoffs", "SLA guarantees"],
          "tools": ["System Design Architecture"]
        },
        {
          "day": 28,
          "topic": "Capstone Implementation: RAG & Agentic Feature Integration",
          "learningObjectives": ["Integrating dynamic vector retrieval with autonomous tool execution"],
          "tools": ["LangChain / Custom Engine"]
        },
        {
          "day": 29,
          "topic": "Capstone Testing, Evaluation Benchmarks & Edge Cases",
          "learningObjectives": ["Automated regression test suits for LLMs", "Synthetic dataset evaluation"],
          "tools": ["DeepEval", "Ragas"]
        },
        {
          "day": 30,
          "topic": "Capstone Production Deployment & CI/CD",
          "learningObjectives": ["Automated deployment pipelines for AI microservices"],
          "tools": ["GitHub Actions", "Google Cloud Run"]
        },
        {
          "day": 31,
          "topic": "Final Capstone Demo & Architectural Defense",
          "learningObjectives": ["Presenting end-to-end AI project, defending design decisions, handling live Q&A"],
          "tools": ["Live Presentation & System Defense"]
        }
      ]
    }
  ]
};
