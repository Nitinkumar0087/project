import React from 'react';
import { Bot, Volume2, Mic, Brain, Sparkles, VolumeX, RotateCcw } from 'lucide-react';
import { AIStatus, InterviewDifficulty } from '../types';

interface AIInterviewerAvatarProps {
  status: AIStatus;
  roleName: string;
  difficulty: InterviewDifficulty;
  questionText?: string;
  questionNumber: number;
  totalQuestions: number;
  isFollowUp?: boolean;
  onRepeatQuestion?: () => void;
}

export const AIInterviewerAvatar: React.FC<AIInterviewerAvatarProps> = ({
  status,
  roleName,
  difficulty,
  questionText,
  questionNumber,
  totalQuestions,
  isFollowUp,
  onRepeatQuestion,
}) => {
  const getStatusBadge = () => {
    switch (status) {
      case 'speaking':
        return (
          <span className="px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 text-xs font-semibold flex items-center gap-1.5 animate-pulse">
            <Volume2 className="w-3.5 h-3.5 text-indigo-400" />
            <span>AI Speaking...</span>
          </span>
        );
      case 'listening':
        return (
          <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-semibold flex items-center gap-1.5 animate-pulse">
            <Mic className="w-3.5 h-3.5 text-emerald-400" />
            <span>Listening to Answer...</span>
          </span>
        );
      case 'evaluating':
        return (
          <span className="px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-xs font-semibold flex items-center gap-1.5 animate-pulse">
            <Brain className="w-3.5 h-3.5 text-cyan-400" />
            <span>Evaluating & Generating Follow-up...</span>
          </span>
        );
      case 'completed':
        return (
          <span className="px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/40 text-xs font-semibold flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>Interview Completed</span>
          </span>
        );
      default:
        return (
          <span className="px-3 py-1 rounded-full bg-slate-800 text-slate-300 border border-slate-700 text-xs font-semibold flex items-center gap-1.5">
            <Bot className="w-3.5 h-3.5 text-slate-400" />
            <span>AI Ready</span>
          </span>
        );
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 md:p-6 flex flex-col justify-between h-full relative overflow-hidden shadow-xl">
      {/* Background Subtle Gradient */}
      <div className="absolute -top-24 -left-24 w-60 h-60 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Header */}
      <div className="flex items-center justify-between mb-4 z-10">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 font-bold">
            H
          </div>
          <div>
            <h3 className="text-sm font-bold text-white leading-tight">Hirely AI Interviewer</h3>
            <p className="text-xs text-slate-400">{roleName} Specialist</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {isFollowUp && (
            <span className="px-2 py-0.5 text-[10px] uppercase font-bold tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded">
              Adaptive Follow-up
            </span>
          )}
          {getStatusBadge()}
        </div>
      </div>

      {/* AI Visual Avatar Center */}
      <div className="my-6 flex flex-col items-center justify-center z-10 space-y-4">
        <div className="relative">
          {/* Pulsing Waveform Rings when speaking or evaluating */}
          {status === 'speaking' && (
            <>
              <div className="absolute -inset-4 rounded-full bg-indigo-500/20 animate-ping opacity-75" />
              <div className="absolute -inset-8 rounded-full bg-indigo-500/10 animate-pulse" />
            </>
          )}

          {status === 'evaluating' && (
            <div className="absolute -inset-6 rounded-full bg-cyan-500/20 animate-spin opacity-50" style={{ animationDuration: '4s' }} />
          )}

          {/* Core Avatar Box */}
          <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-gradient-to-tr from-indigo-900 via-indigo-700 to-cyan-500 p-1 shadow-2xl relative z-10 flex items-center justify-center">
            <div className="w-full h-full rounded-full bg-slate-950 flex items-center justify-center relative overflow-hidden">
              <Bot className={`w-12 h-12 text-indigo-300 transition-transform ${status === 'speaking' ? 'scale-110' : ''}`} />

              {/* Animated Wave Bars inside Avatar when Speaking */}
              {status === 'speaking' && (
                <div className="absolute bottom-2 flex items-center justify-center gap-1">
                  <span className="w-1 h-3 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <span className="w-1 h-5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <span className="w-1 h-2 bg-cyan-300 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  <span className="w-1 h-4 bg-indigo-300 rounded-full animate-bounce" style={{ animationDelay: '450ms' }} />
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Dynamic Question Display Box */}
        {questionText && (
          <div className="w-full bg-slate-950/80 border border-slate-800 rounded-xl p-4 text-center space-y-2 relative">
            <div className="flex items-center justify-between text-xs text-slate-400 font-medium px-1">
              <span>
                Question {questionNumber} of {totalQuestions}
              </span>
              {onRepeatQuestion && (
                <button
                  onClick={onRepeatQuestion}
                  className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1 focus:outline-none text-xs"
                  title="Repeat question audio"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Repeat Question</span>
                </button>
              )}
            </div>

            <p className="text-sm sm:text-base font-semibold text-slate-100 leading-relaxed italic">
              "{questionText}"
            </p>
          </div>
        )}
      </div>

      {/* Footer Info */}
      <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400 z-10">
        <span className="flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
          Role: <strong className="text-slate-200">{roleName}</strong>
        </span>
        <span className="flex items-center gap-1">
          Difficulty: <strong className="text-slate-200">{difficulty}</strong>
        </span>
      </div>
    </div>
  );
};
