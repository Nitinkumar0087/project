import React, { useState, useEffect, useRef } from 'react';
import { Video, Mic, Camera, Settings2, Play, CheckCircle2, AlertCircle, RefreshCw, User, Award, Check } from 'lucide-react';
import { Candidate, InterviewConfig, InterviewDifficulty, InterviewRole } from '../types';

interface InterviewSetupProps {
  initialRole?: InterviewRole;
  onStartInterview: (config: InterviewConfig, selectedCandidate?: Candidate) => void;
  onCancel: () => void;
}

export const InterviewSetup: React.FC<InterviewSetupProps> = ({
  initialRole = 'Software Developer',
  onStartInterview,
  onCancel,
}) => {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [selectedCandidate, setSelectedCandidate] = useState<Candidate | null>(null);
  const [role, setRole] = useState<InterviewRole>(initialRole);
  const [customRole, setCustomRole] = useState<string>('');
  const [difficulty, setDifficulty] = useState<InterviewDifficulty>('Medium');
  const [durationMinutes, setDurationMinutes] = useState<number>(20);
  const [totalQuestions, setTotalQuestions] = useState<number>(8);

  // Device Permissions State
  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);
  const [hasMicPermission, setHasMicPermission] = useState<boolean | null>(null);
  const [deviceError, setDeviceError] = useState<string | null>(null);
  const [isTestingDevices, setIsTestingDevices] = useState<boolean>(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Fetch Candidates list on mount
  useEffect(() => {
    fetch('/api/candidates')
      .then((res) => res.json())
      .then((data: Candidate[]) => {
        if (Array.isArray(data) && data.length > 0) {
          setCandidates(data);
          setSelectedCandidate(data[0]); // default to first candidate
        }
      })
      .catch((err) => console.warn('Failed to load candidate list:', err));
  }, []);

  // Update config defaults if candidate selected
  const handleSelectCandidate = (cand: Candidate) => {
    setSelectedCandidate(cand);
    if (cand.jobRole.toLowerCase().includes('data') || cand.jobRole.toLowerCase().includes('ml')) {
      setRole('AI/ML Engineer');
    } else if (cand.jobRole.toLowerCase().includes('frontend') || cand.jobRole.toLowerCase().includes('software')) {
      setRole('Software Developer');
    } else {
      setRole('Custom');
      setCustomRole(cand.jobRole);
    }
  };

  // Test media devices
  const checkMediaDevices = async () => {
    setIsTestingDevices(true);
    setDeviceError(null);

    // Stop existing stream if any
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: true,
      });

      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }

      setHasCameraPermission(true);
      setHasMicPermission(true);
    } catch (err: any) {
      console.warn('Media devices test failed:', err);
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setDeviceError('Camera and microphone permissions were denied. Please grant permission in your browser address bar.');
        setHasCameraPermission(false);
        setHasMicPermission(false);
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        setDeviceError('No camera or microphone found on your device.');
        setHasCameraPermission(false);
        setHasMicPermission(false);
      } else {
        setDeviceError(`Media device error: ${err.message || 'Unable to access camera or microphone'}`);
      }
    } finally {
      setIsTestingDevices(false);
    }
  };

  useEffect(() => {
    checkMediaDevices();

    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  const handleStart = () => {
    if (role === 'Custom' && !customRole.trim()) {
      setDeviceError('Please enter your custom job title.');
      return;
    }

    // Clean up test stream so room can acquire stream
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }

    onStartInterview(
      {
        role,
        customRole: role === 'Custom' ? customRole.trim() : undefined,
        difficulty,
        durationMinutes,
        totalQuestions,
        selectedCandidateId: selectedCandidate?.id,
      },
      selectedCandidate || undefined
    );
  };

  return (
    <div className="min-h-[calc(100vh-65px)] bg-slate-950 text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold">
            <Settings2 className="w-3.5 h-3.5" />
            <span>AI Cohort Interview Setup</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">
            Configure Candidate & Interview Parameters
          </h1>
          <p className="text-slate-400 text-sm max-w-xl mx-auto">
            Select a candidate profile from the 31-Day AI Cohort, verify target difficulty, and test your webcam & microphone.
          </p>
        </div>

        {/* Candidate Selector Bar */}
        {candidates.length > 0 && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3 shadow-xl">
            <div className="flex items-center justify-between">
              <label className="text-sm font-bold text-white flex items-center gap-2">
                <User className="w-4 h-4 text-indigo-400" />
                <span>Select Candidate Profile (Synthetic Cohort Dataset)</span>
              </label>
              <span className="text-xs text-slate-400">3 Profiles Available</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {candidates.map((cand) => {
                const isSelected = selectedCandidate?.id === cand.id;
                return (
                  <button
                    key={cand.id}
                    type="button"
                    onClick={() => handleSelectCandidate(cand)}
                    className={`p-4 rounded-xl border text-left transition-all relative ${
                      isSelected
                        ? 'bg-indigo-950/60 border-indigo-500 text-white shadow-lg shadow-indigo-500/10 ring-1 ring-indigo-500'
                        : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700 hover:text-white'
                    }`}
                  >
                    {isSelected && (
                      <span className="absolute top-3 right-3 w-5 h-5 rounded-full bg-indigo-500 text-white flex items-center justify-center text-xs">
                        <Check className="w-3 h-3 stroke-[3]" />
                      </span>
                    )}

                    <p className="font-bold text-sm text-white">{cand.name}</p>
                    <p className="text-xs text-indigo-300 font-medium">{cand.jobRole} ({cand.yearsExperience} yrs)</p>
                    <div className="mt-2 text-[11px] text-slate-400 space-y-1">
                      <p>Missions: {cand.missionsCompleted}/31 ({cand.missionsFirstTry} 1st try)</p>
                      <p className="truncate">Capstone: {cand.capstoneProject || 'None'}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
          {/* Configuration Form (7 cols) */}
          <div className="md:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6 shadow-xl">
            {/* 1. Interview Role */}
            <div className="space-y-3">
              <label className="text-sm font-bold text-white flex items-center justify-between">
                <span>1. Target Interview Role</span>
                <span className="text-xs font-normal text-slate-400">Auto-filled</span>
              </label>

              <div className="grid grid-cols-2 gap-2.5">
                {(['Software Developer', 'Data Analyst', 'AI/ML Engineer', 'HR', 'Custom'] as InterviewRole[]).map(
                  (r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setRole(r)}
                      className={`p-3 rounded-xl border text-xs font-semibold text-left transition-all ${
                        role === r
                          ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-md shadow-indigo-500/10'
                          : 'bg-slate-800/60 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:text-white'
                      }`}
                    >
                      {r}
                    </button>
                  )
                )}
              </div>

              {role === 'Custom' && (
                <div className="pt-2">
                  <input
                    type="text"
                    value={customRole}
                    onChange={(e) => setCustomRole(e.target.value)}
                    placeholder="e.g. Senior AI Engineer, ML System Designer"
                    className="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 placeholder-slate-500"
                  />
                </div>
              )}
            </div>

            {/* 2. Interview Difficulty */}
            <div className="space-y-3">
              <label className="text-sm font-bold text-white">2. Initial Interview Difficulty</label>
              <div className="grid grid-cols-3 gap-2.5">
                {(['Easy', 'Medium', 'Hard'] as InterviewDifficulty[]).map((diff) => (
                  <button
                    key={diff}
                    type="button"
                    onClick={() => setDifficulty(diff)}
                    className={`py-2.5 px-3 rounded-xl border text-xs font-semibold text-center transition-all ${
                      difficulty === diff
                        ? diff === 'Easy'
                          ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                          : diff === 'Medium'
                          ? 'bg-indigo-500/20 border-indigo-500 text-indigo-300'
                          : 'bg-rose-500/20 border-rose-500 text-rose-300'
                        : 'bg-slate-800/60 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    {diff}
                  </button>
                ))}
              </div>
            </div>

            {/* 3. Duration & Questions */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-bold text-white">Duration</label>
                <div className="grid grid-cols-3 gap-1.5">
                  {[10, 20, 30].map((mins) => (
                    <button
                      key={mins}
                      type="button"
                      onClick={() => setDurationMinutes(mins)}
                      className={`py-2 rounded-lg border text-xs font-semibold text-center transition-all ${
                        durationMinutes === mins
                          ? 'bg-indigo-600/30 border-indigo-500 text-white'
                          : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:text-white'
                      }`}
                    >
                      {mins}m
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-white">Minimum Questions</label>
                <div className="grid grid-cols-3 gap-1.5">
                  {[8, 10, 12].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => setTotalQuestions(num)}
                      className={`py-2 rounded-lg border text-xs font-semibold text-center transition-all ${
                        totalQuestions === num
                          ? 'bg-indigo-600/30 border-indigo-500 text-white'
                          : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:text-white'
                      }`}
                    >
                      {num} Qs
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Camera & Mic Test Panel (5 cols) */}
          <div className="md:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 shadow-xl">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <Camera className="w-4 h-4 text-indigo-400" />
                <span>Webcam & Mic Preview</span>
              </h2>
              <button
                type="button"
                onClick={checkMediaDevices}
                disabled={isTestingDevices}
                className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 focus:outline-none"
              >
                <RefreshCw className={`w-3 h-3 ${isTestingDevices ? 'animate-spin' : ''}`} />
                <span>Test Devices</span>
              </button>
            </div>

            {/* Video Box */}
            <div className="relative aspect-video bg-slate-950 rounded-xl overflow-hidden border border-slate-800 flex items-center justify-center">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className={`w-full h-full object-cover transform -scale-x-100 ${
                  hasCameraPermission ? 'block' : 'hidden'
                }`}
              />

              {!hasCameraPermission && (
                <div className="p-4 text-center space-y-2">
                  <Video className="w-8 h-8 text-slate-600 mx-auto" />
                  <p className="text-xs text-slate-400">
                    {isTestingDevices ? 'Requesting media permissions...' : 'Camera preview inactive'}
                  </p>
                </div>
              )}

              {/* Status Badges */}
              <div className="absolute top-2 left-2 flex items-center gap-1.5">
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-semibold flex items-center gap-1 ${
                    hasCameraPermission
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  <Camera className="w-3 h-3" />
                  <span>{hasCameraPermission ? 'Cam Ready' : 'Cam Off'}</span>
                </span>

                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-semibold flex items-center gap-1 ${
                    hasMicPermission
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  <Mic className="w-3 h-3" />
                  <span>{hasMicPermission ? 'Mic Ready' : 'Mic Off'}</span>
                </span>
              </div>
            </div>

            {/* Device Error Guidance */}
            {deviceError && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold">Device Alert</p>
                  <p className="mt-0.5 text-rose-300/90">{deviceError}</p>
                </div>
              </div>
            )}

            <p className="text-[11px] text-slate-400 leading-normal">
              Note: Camera & microphone access is required so Hirely AI can listen to your answers in real time.
            </p>

            {/* Action Buttons */}
            <div className="pt-2 flex items-center gap-3">
              <button
                type="button"
                onClick={onCancel}
                className="w-1/3 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-sm transition-colors"
              >
                Back
              </button>

              <button
                type="button"
                onClick={handleStart}
                className="w-2/3 py-3 rounded-xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-cyan-500 hover:from-indigo-500 hover:to-cyan-400 text-white font-bold text-sm shadow-lg shadow-indigo-600/25 transition-all flex items-center justify-center gap-2 group"
              >
                <Play className="w-4 h-4 fill-white group-hover:scale-110 transition-transform" />
                <span>Start Interview</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

