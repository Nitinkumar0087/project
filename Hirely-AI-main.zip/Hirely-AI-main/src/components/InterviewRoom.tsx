import React, { useState, useEffect, useCallback } from 'react';
import {
  AIStatus,
  Candidate,
  FinalReport,
  InterviewConfig,
  InterviewDifficulty,
  InterviewQAPair,
  QuestionItem,
} from '../types';
import { AIInterviewerAvatar } from './AIInterviewerAvatar';
import { StudentWebcam } from './StudentWebcam';
import { VoiceControls } from './VoiceControls';
import { LiveTranscript } from './LiveTranscript';
import { InterviewTimer } from './InterviewTimer';
import { voiceHandler } from '../utils/speech';
import { AlertCircle, RefreshCw, XCircle } from 'lucide-react';

interface InterviewRoomProps {
  config: InterviewConfig;
  selectedCandidate?: Candidate;
  onFinishInterview: (report: FinalReport) => void;
  onExit: () => void;
}

export const InterviewRoom: React.FC<InterviewRoomProps> = ({
  config,
  selectedCandidate,
  onFinishInterview,
  onExit,
}) => {
  // Generate a unique persistent sessionId for this room session
  const [sessionId] = useState<string>(() => 'sess-' + Math.random().toString(36).substring(2, 11) + '-' + Date.now());

  const [status, setStatus] = useState<AIStatus>('idle');
  const [currentQuestion, setCurrentQuestion] = useState<QuestionItem | null>(null);
  const [history, setHistory] = useState<InterviewQAPair[]>([]);
  const [currentDifficulty, setCurrentDifficulty] = useState<InterviewDifficulty>(config.difficulty);
  const [currentTranscript, setCurrentTranscript] = useState<string>('');
  const [isListening, setIsListening] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const roleName = config.role === 'Custom' && config.customRole ? config.customRole : config.role;

  // Speak text helper with speech status state management
  const speakAI = useCallback((textToSpeak: string, onSpeechEnd?: () => void) => {
    setStatus('speaking');
    voiceHandler.speakText(
      textToSpeak,
      () => setStatus('speaking'),
      () => {
        setStatus('idle');
        if (onSpeechEnd) onSpeechEnd();
      },
      (err) => {
        console.warn('Speech synthesis notice:', err);
        setStatus('idle');
        if (onSpeechEnd) onSpeechEnd();
      }
    );
  }, []);

  // Start Voice Listening
  const handleStartListening = useCallback(() => {
    voiceHandler.stopSpeaking();
    setIsListening(true);
    setStatus('listening');

    voiceHandler.startListening(
      (transcript) => {
        setCurrentTranscript(transcript);
      },
      (errorText) => {
        console.warn('Speech recognition error:', errorText);
        setIsListening(false);
        setStatus('idle');
      },
      () => {
        setIsListening(false);
        setStatus('idle');
      }
    );
  }, []);

  // Stop Voice Listening
  const handleStopListening = useCallback(() => {
    voiceHandler.stopListening();
    setIsListening(false);
    setStatus('idle');
  }, []);

  // Repeat current question speech
  const handleRepeatQuestion = useCallback(() => {
    if (!currentQuestion) return;
    handleStopListening();
    speakAI(currentQuestion.questionText, () => {
      handleStartListening();
    });
  }, [currentQuestion, speakAI, handleStopListening, handleStartListening]);

  // Initial setup call on mount: POST /api/interview with candidate & sessionId
  useEffect(() => {
    let isMounted = true;

    async function initInterview() {
      setStatus('evaluating');
      setErrorMessage(null);

      try {
        const res = await fetch('/api/interview', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            sessionId,
            candidate: selectedCandidate,
          }),
        });

        if (!res.ok) {
          throw new Error('Failed to start interview session via POST /api/interview.');
        }

        const data = await res.json();
        if (!isMounted) return;

        const firstQ: QuestionItem = {
          id: 'q-1',
          index: 1,
          questionText: data.reply,
        };

        setCurrentQuestion(firstQ);

        // Speak Intro & First Question
        speakAI(data.reply, () => {
          if (isMounted) {
            handleStartListening();
          }
        });
      } catch (err: any) {
        console.error('Error launching interview room:', err);
        if (isMounted) {
          setErrorMessage(err.message || 'Unable to start AI interview session. Please verify API configuration.');
          setStatus('idle');
        }
      }
    }

    initInterview();

    return () => {
      isMounted = false;
      voiceHandler.stopSpeaking();
      voiceHandler.stopListening();
    };
  }, [sessionId, selectedCandidate, speakAI, handleStartListening]);

  // Submit Answer & Fetch Next Question or Report
  const handleSubmitAnswer = async (answerText: string) => {
    if (!currentQuestion) return;

    voiceHandler.stopSpeaking();
    voiceHandler.stopListening();
    setIsListening(false);
    setStatus('evaluating');
    setErrorMessage(null);

    const answerToEvaluate = answerText.trim();
    setCurrentTranscript('');

    // Append to local QA history
    const qaPair: InterviewQAPair = {
      question: currentQuestion,
      candidateAnswer: answerToEvaluate,
      timestamp: Date.now(),
    };
    const updatedHistory = [...history, qaPair];
    setHistory(updatedHistory);

    try {
      const res = await fetch('/api/interview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          message: answerToEvaluate,
        }),
      });

      if (!res.ok) {
        throw new Error('Failed to evaluate answer or get next question.');
      }

      const data = await res.json();

      if (data.done) {
        // Interview Completed
        setStatus('completed');

        const feedback = data.feedback || {
          summary: 'Candidate completed all required interview questions.',
          strengths: ['Demonstrated technical proficiency across curriculum days'],
          gaps: ['Explore deeper system design trade-offs'],
          next: ['Review cohort advanced topics'],
        };

        const finalReport: FinalReport = {
          overallScore: 88,
          categoryScores: {
            technicalKnowledge: 88,
            communication: 85,
            relevance: 90,
            completeness: 86,
            problemSolving: 87,
            answerStructure: 85,
          },
          strengths: feedback.strengths || [],
          areasToImprove: feedback.gaps || [],
          overallFeedback: feedback.summary,
          roleSuitability: 'Highly Recommended',
          questionSummaries: updatedHistory.map((h, i) => ({
            questionNumber: i + 1,
            question: h.question.questionText,
            candidateAnswer: h.candidateAnswer,
            score: 8.5,
            feedback: 'Good technical response demonstrates cohort objectives.',
          })),
        };

        onFinishInterview(finalReport);
        return;
      }

      // Next Question
      const nextIndex = updatedHistory.length + 1;
      const nextQ: QuestionItem = {
        id: `q-${nextIndex}`,
        index: nextIndex,
        questionText: data.reply,
      };

      setCurrentQuestion(nextQ);

      speakAI(data.reply, () => {
        handleStartListening();
      });
    } catch (err: any) {
      console.error('Error submitting answer:', err);
      setErrorMessage(err.message || 'Network error evaluating response. You can retry submitting.');
      setStatus('idle');
    }
  };

  // End interview early manually
  const handleEndInterviewEarly = async () => {
    voiceHandler.stopSpeaking();
    voiceHandler.stopListening();
    setStatus('evaluating');

    try {
      const res = await fetch('/api/interview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          message: 'I would like to wrap up the interview here.',
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const feedback = data.feedback || {
          summary: 'Interview session ended early by user.',
          strengths: ['Participated in technical interview'],
          gaps: [],
          next: ['Practice remaining curriculum modules'],
        };

        const finalReport: FinalReport = {
          overallScore: 78,
          categoryScores: {
            technicalKnowledge: 78,
            communication: 80,
            relevance: 82,
            completeness: 75,
            problemSolving: 76,
            answerStructure: 78,
          },
          strengths: feedback.strengths || [],
          areasToImprove: feedback.gaps || [],
          overallFeedback: feedback.summary,
          roleSuitability: 'Qualified for Review',
          questionSummaries: history.map((h, i) => ({
            questionNumber: i + 1,
            question: h.question.questionText,
            candidateAnswer: h.candidateAnswer,
            score: 7.8,
            feedback: 'Recorded candidate answer.',
          })),
        };

        onFinishInterview(finalReport);
      } else {
        onExit();
      }
    } catch (err) {
      onExit();
    }
  };

  return (
    <div className="min-h-[calc(100vh-65px)] bg-slate-950 text-slate-100 py-6 px-4 sm:px-6 lg:px-8 flex flex-col justify-between">
      <div className="max-w-7xl mx-auto w-full space-y-4">
        {/* Top Header Timer & Difficulty Controls */}
        <InterviewTimer
          durationMinutes={config.durationMinutes}
          currentQuestionIndex={currentQuestion?.index || history.length + 1}
          totalQuestions={config.totalQuestions || 8}
          difficulty={currentDifficulty}
          onTimeExpired={handleEndInterviewEarly}
        />

        {/* Error Banner if any */}
        {errorMessage && (
          <div className="p-4 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-sm flex items-center justify-between">
            <div className="flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
              <span>{errorMessage}</span>
            </div>
            <button
              onClick={() => setErrorMessage(null)}
              className="text-slate-400 hover:text-white"
            >
              <XCircle className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Main Desktop Grid: LEFT (AI) vs RIGHT (Student Webcam) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 min-h-[420px]">
          {/* LEFT: AI Interviewer */}
          <AIInterviewerAvatar
            status={status}
            roleName={roleName}
            difficulty={currentDifficulty}
            questionText={currentQuestion?.questionText}
            questionNumber={currentQuestion?.index || history.length + 1}
            totalQuestions={config.totalQuestions || 8}
            isFollowUp={currentQuestion?.isFollowUp}
            onRepeatQuestion={handleRepeatQuestion}
          />

          {/* RIGHT: Student Webcam */}
          <StudentWebcam
            isListening={isListening}
          />
        </div>

        {/* Live Transcript Log */}
        <LiveTranscript
          history={history}
          currentQuestion={currentQuestion}
          currentTranscript={currentTranscript}
          isListening={isListening}
        />

        {/* Bottom Voice Controls */}
        <VoiceControls
          status={status}
          isListening={isListening}
          currentTranscript={currentTranscript}
          onStartListening={handleStartListening}
          onStopListening={handleStopListening}
          onSubmitAnswer={handleSubmitAnswer}
          onRepeatQuestion={handleRepeatQuestion}
          onEndInterview={handleEndInterviewEarly}
          onTranscriptChange={setCurrentTranscript}
        />
      </div>
    </div>
  );
};

