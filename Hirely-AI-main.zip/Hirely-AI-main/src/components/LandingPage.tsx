import React from 'react';
import { Video, Mic, Sparkles, Brain, Award, CheckCircle, ArrowRight, ShieldCheck, Zap, MessageSquareQuote } from 'lucide-react';
import { InterviewRole } from '../types';

interface LandingPageProps {
  onStartSetup: (role?: InterviewRole) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onStartSetup }) => {
  const roles: { role: InterviewRole; title: string; desc: string; icon: string; count: string }[] = [
    {
      role: 'Software Developer',
      title: 'Software Developer',
      desc: 'System design, algorithms, coding concepts, STAR framework, and behavioral scenarios.',
      icon: '💻',
      count: 'Popular',
    },
    {
      role: 'AI/ML Engineer',
      title: 'AI/ML Engineer',
      desc: 'Machine learning fundamentals, deep learning, model deployment, and real-world ML architecture.',
      icon: '🧠',
      count: 'High Demand',
    },
    {
      role: 'Data Analyst',
      title: 'Data Analyst',
      desc: 'SQL queries, data visualization, business problem solving, metrics, and data storytelling.',
      icon: '📊',
      count: 'Popular',
    },
    {
      role: 'HR',
      title: 'HR & Management',
      desc: 'Conflict resolution, leadership, team coordination, policy enforcement, and situational judgments.',
      icon: '👥',
      count: 'Essential',
    },
    {
      role: 'Custom',
      title: 'Custom Job Role',
      desc: 'Define your specific target job title, custom niche technology, or specific industry focus.',
      icon: '🎯',
      count: 'Flexible',
    },
  ];

  return (
    <div className="min-h-[calc(100vh-65px)] bg-slate-950 text-slate-100 flex flex-col justify-between">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        {/* Glow Effects */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-indigo-600/15 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute top-1/3 right-10 w-[300px] h-[300px] bg-cyan-500/10 rounded-full blur-[100px] pointer-events-none" />

        <div className="relative text-center max-w-4xl mx-auto space-y-6">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900 border border-indigo-500/30 text-indigo-300 text-xs font-semibold tracking-wide shadow-inner">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
            <span>Next-Gen Voice & Vision AI Interviewer</span>
          </div>

          {/* Heading */}
          <h1 className="text-4xl sm:text-6xl font-extrabold text-white tracking-tight leading-[1.15]">
            Hirely AI
            <span className="block text-2xl sm:text-4xl text-slate-400 font-semibold mt-2">
              Your AI-Powered Interview Partner
            </span>
          </h1>

          {/* Core Tagline */}
          <p className="text-lg sm:text-xl text-slate-300 max-w-2xl mx-auto leading-relaxed">
            Practice real interviews with an AI that listens, evaluates, and adapts.
          </p>

          {/* Primary CTA */}
          <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => onStartSetup()}
              className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-cyan-500 hover:from-indigo-500 hover:to-cyan-400 text-white font-bold text-lg shadow-xl shadow-indigo-600/25 transition-all transform hover:-translate-y-0.5 flex items-center justify-center gap-3 group"
            >
              <Video className="w-5 h-5 text-indigo-100 group-hover:scale-110 transition-transform" />
              <span>Start Mock Interview</span>
              <ArrowRight className="w-5 h-5 opacity-80 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          {/* Feature Highlights */}
          <div className="pt-8 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto text-left">
            <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
                <Mic className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-slate-400">Voice Interaction</p>
                <p className="text-sm font-semibold text-slate-200">Speech-to-Text</p>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
                <Video className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-slate-400">Real Webcam</p>
                <p className="text-sm font-semibold text-slate-200">Live Camera Room</p>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                <Brain className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-slate-400">Adaptive AI</p>
                <p className="text-sm font-semibold text-slate-200">Smart Follow-ups</p>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
                <Award className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-slate-400">Deep Feedback</p>
                <p className="text-sm font-semibold text-slate-200">Final Report</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Role Selection Shortcut Cards */}
      <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
              <span>Select Your Interview Track</span>
            </h2>
            <p className="text-slate-400 text-sm mt-1">
              Choose a role below or create a custom role to configure difficulty & time.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {roles.map((item) => (
            <button
              key={item.role}
              onClick={() => onStartSetup(item.role)}
              className="p-6 rounded-2xl bg-slate-900/80 hover:bg-slate-800/90 border border-slate-800 hover:border-indigo-500/50 text-left transition-all duration-200 hover:-translate-y-1 shadow-lg hover:shadow-indigo-500/10 flex flex-col justify-between group focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-3xl p-2 bg-slate-800/80 rounded-xl border border-slate-700/50">
                    {item.icon}
                  </span>
                  <span className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                    {item.count}
                  </span>
                </div>
                <h3 className="text-lg font-bold text-white group-hover:text-indigo-300 transition-colors">
                  {item.title}
                </h3>
                <p className="text-slate-400 text-sm mt-2 leading-relaxed">
                  {item.desc}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-semibold text-indigo-400 group-hover:text-indigo-300">
                <span>Configure & Start</span>
                <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section className="py-12 bg-slate-900/40 border-t border-slate-800/80 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <h2 className="text-2xl font-bold text-white">How Hirely AI Works</h2>
            <p className="text-slate-400 text-sm mt-1">Real voice conversation designed to mirror actual hiring loops.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="relative p-6 rounded-xl bg-slate-900 border border-slate-800">
              <div className="w-10 h-10 rounded-xl bg-indigo-600/20 text-indigo-400 font-extrabold flex items-center justify-center mb-4 text-lg border border-indigo-500/30">
                1
              </div>
              <h3 className="font-bold text-white text-base">Setup & Permission</h3>
              <p className="text-slate-400 text-sm mt-2 leading-relaxed">
                Select target role, difficulty, and duration. Enable camera & microphone for realistic face-to-face interaction.
              </p>
            </div>

            <div className="relative p-6 rounded-xl bg-slate-900 border border-slate-800">
              <div className="w-10 h-10 rounded-xl bg-cyan-600/20 text-cyan-400 font-extrabold flex items-center justify-center mb-4 text-lg border border-cyan-500/30">
                2
              </div>
              <h3 className="font-bold text-white text-base">Live Voice Conversation</h3>
              <p className="text-slate-400 text-sm mt-2 leading-relaxed">
                AI asks questions via text-to-speech. You speak your answers naturally using Speech-to-Text.
              </p>
            </div>

            <div className="relative p-6 rounded-xl bg-slate-900 border border-slate-800">
              <div className="w-10 h-10 rounded-xl bg-emerald-600/20 text-emerald-400 font-extrabold flex items-center justify-center mb-4 text-lg border border-emerald-500/30">
                3
              </div>
              <h3 className="font-bold text-white text-base">Adaptive Follow-ups & Report</h3>
              <p className="text-slate-400 text-sm mt-2 leading-relaxed">
                AI evaluates accuracy, relevance, and communication in real time. Receive a comprehensive score report upon completion.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Simple Footer */}
      <footer className="py-6 border-t border-slate-800 text-center text-xs text-slate-500">
        <p>© Hirely AI — Your AI-Powered Interview Partner. Powered by Gemini API.</p>
      </footer>
    </div>
  );
};
