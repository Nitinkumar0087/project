import React, { useState } from 'react';
import { Mic, MicOff, Send, RotateCcw, Square, AlertCircle, MessageSquare, Sparkles } from 'lucide-react';
import { AIStatus } from '../types';

interface VoiceControlsProps {
  status: AIStatus;
  isListening: boolean;
  currentTranscript: string;
  onStartListening: () => void;
  onStopListening: () => void;
  onSubmitAnswer: (answer: string) => void;
  onRepeatQuestion: () => void;
  onEndInterview: () => void;
  onTranscriptChange: (text: string) => void;
}

export const VoiceControls: React.FC<VoiceControlsProps> = ({
  status,
  isListening,
  currentTranscript,
  onStartListening,
  onStopListening,
  onSubmitAnswer,
  onRepeatQuestion,
  onEndInterview,
  onTranscriptChange,
}) => {
  const [showTextFallback, setShowTextFallback] = useState<boolean>(false);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!currentTranscript.trim()) return;
    onSubmitAnswer(currentTranscript);
  };

  const isBusy = status === 'speaking' || status === 'evaluating';

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-2xl space-y-4">
      {/* Primary Interaction Status Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Left: Voice Status Indicator */}
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <button
            type="button"
            onClick={isListening ? onStopListening : onStartListening}
            disabled={isBusy}
            className={`px-5 py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2.5 transition-all w-full sm:w-auto shadow-lg ${
              isListening
                ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-600/20 animate-pulse'
                : isBusy
                ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/20'
            }`}
          >
            {isListening ? (
              <>
                <Square className="w-4 h-4 fill-white" />
                <span>Stop Listening</span>
              </>
            ) : (
              <>
                <Mic className="w-4 h-4" />
                <span>{isBusy ? 'AI Operating...' : 'Speak Answer'}</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={onRepeatQuestion}
            disabled={isBusy}
            className="p-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors disabled:opacity-50"
            title="Repeat Question Audio"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        {/* Center: Live Spoken Transcript Input & Fallback toggle */}
        <div className="flex-1 w-full flex items-center gap-2">
          <div className="relative flex-1">
            <input
              type="text"
              value={currentTranscript}
              onChange={(e) => onTranscriptChange(e.target.value)}
              placeholder={
                isListening
                  ? 'Listening to your voice... Speak now'
                  : isBusy
                  ? 'AI is speaking / evaluating response...'
                  : 'Speak into mic or type response here...'
              }
              disabled={isBusy}
              className="w-full pl-4 pr-10 py-3 bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-colors"
            />
            {isListening && (
              <span className="absolute right-3 top-1/2 -translate-y-1/2 w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            )}
          </div>

          <button
            type="button"
            onClick={() => handleSubmit()}
            disabled={isBusy || !currentTranscript.trim()}
            className="px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-600 text-white font-bold text-sm shadow-md shadow-indigo-600/20 transition-all flex items-center justify-center gap-2 shrink-0"
          >
            <span>Submit</span>
            <Send className="w-4 h-4" />
          </button>
        </div>

        {/* Right: End Interview */}
        <button
          type="button"
          onClick={onEndInterview}
          className="px-4 py-3 rounded-xl bg-slate-800 hover:bg-rose-950/50 hover:border-rose-500/50 border border-slate-700 text-slate-300 hover:text-rose-300 font-semibold text-xs transition-all shrink-0"
        >
          End Interview
        </button>
      </div>

      {/* Voice Instruction Helper */}
      <div className="flex items-center justify-between text-xs text-slate-400 px-1 pt-1">
        <span className="flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
          <span>Tip: Click "Speak Answer" and answer naturally. Click "Submit" when finished speaking.</span>
        </span>
        <button
          onClick={() => setShowTextFallback(!showTextFallback)}
          className="text-slate-400 hover:text-slate-200 underline text-[11px]"
        >
          {showTextFallback ? 'Hide Text Area' : 'Trouble with mic? Open full text box'}
        </button>
      </div>

      {/* Optional Expanded Text Fallback */}
      {showTextFallback && (
        <div className="pt-2">
          <textarea
            value={currentTranscript}
            onChange={(e) => onTranscriptChange(e.target.value)}
            rows={3}
            placeholder="Type your detailed interview answer here if speech recognition is unavailable or noisy..."
            className="w-full p-3 bg-slate-950 border border-slate-800 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
          />
        </div>
      )}
    </div>
  );
};
