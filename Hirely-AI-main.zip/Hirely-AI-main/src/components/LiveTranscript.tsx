import React, { useRef, useEffect } from 'react';
import { Bot, User, CheckCircle2, MessageSquareText } from 'lucide-react';
import { InterviewQAPair, QuestionItem } from '../types';

interface LiveTranscriptProps {
  history: InterviewQAPair[];
  currentQuestion?: QuestionItem | null;
  currentTranscript?: string;
  isListening?: boolean;
}

export const LiveTranscript: React.FC<LiveTranscriptProps> = ({
  history,
  currentQuestion,
  currentTranscript,
  isListening,
}) => {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history, currentTranscript]);

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col h-full max-h-[350px] shadow-lg">
      <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <MessageSquareText className="w-4 h-4 text-indigo-400" />
          <span>Live Conversation Transcript</span>
        </h3>
        <span className="text-[11px] text-slate-400">
          {history.length} Q&A Completed
        </span>
      </div>

      {/* Scrollable Conversation Container */}
      <div className="flex-1 overflow-y-auto space-y-4 pr-1 text-xs sm:text-sm">
        {history.length === 0 && !currentQuestion && !currentTranscript && (
          <div className="text-center text-slate-500 py-8 italic">
            Interview conversation transcript will appear here in real-time...
          </div>
        )}

        {/* Previous Q&A Pairs */}
        {history.map((pair, index) => (
          <div key={pair.question.id || index} className="space-y-2">
            {/* AI Question */}
            <div className="flex items-start gap-2.5">
              <div className="w-6 h-6 rounded-lg bg-indigo-600/30 text-indigo-300 font-bold flex items-center justify-center shrink-0 text-[10px] border border-indigo-500/30">
                AI
              </div>
              <div className="bg-slate-800/80 border border-slate-700/80 p-3 rounded-xl rounded-tl-none text-slate-200">
                <p className="font-semibold text-xs text-indigo-300 mb-0.5">
                  Question {index + 1} {pair.question.isFollowUp ? '(Follow-up)' : ''}
                </p>
                <p className="leading-relaxed">{pair.question.questionText}</p>
              </div>
            </div>

            {/* Student Answer */}
            <div className="flex items-start justify-end gap-2.5 pl-6">
              <div className="bg-indigo-950/40 border border-indigo-800/50 p-3 rounded-xl rounded-tr-none text-slate-200">
                <p className="font-semibold text-[11px] text-cyan-400 mb-0.5">Your Response</p>
                <p className="leading-relaxed italic">
                  "{pair.candidateAnswer.trim() || '(No response recorded)'}"
                </p>

                {pair.evaluation && (
                  <div className="mt-2 pt-2 border-t border-indigo-900/60 flex items-center justify-between text-[11px]">
                    <span className="text-emerald-400 font-semibold flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      Evaluated Score: {pair.evaluation.overall}/10
                    </span>
                    <span className="text-slate-400 truncate max-w-[200px]">
                      {pair.evaluation.feedbackSummary}
                    </span>
                  </div>
                )}
              </div>
              <div className="w-6 h-6 rounded-lg bg-cyan-600/30 text-cyan-300 font-bold flex items-center justify-center shrink-0 text-[10px] border border-cyan-500/30">
                You
              </div>
            </div>
          </div>
        ))}

        {/* Current Active Question */}
        {currentQuestion && (
          <div className="space-y-2 pt-1">
            <div className="flex items-start gap-2.5">
              <div className="w-6 h-6 rounded-lg bg-indigo-600/40 text-indigo-200 font-bold flex items-center justify-center shrink-0 text-[10px] border border-indigo-400/50 animate-pulse">
                AI
              </div>
              <div className="bg-slate-800 border border-indigo-500/40 p-3 rounded-xl rounded-tl-none text-slate-100 shadow-md">
                <p className="font-semibold text-xs text-indigo-300 mb-0.5">
                  Current Question {currentQuestion.index} {currentQuestion.isFollowUp ? '(Adaptive Follow-up)' : ''}
                </p>
                <p className="leading-relaxed font-medium">{currentQuestion.questionText}</p>
              </div>
            </div>

            {/* Live Student Spoken Draft */}
            {(currentTranscript || isListening) && (
              <div className="flex items-start justify-end gap-2.5 pl-6">
                <div className="bg-indigo-950/60 border border-indigo-500/50 p-3 rounded-xl rounded-tr-none text-slate-100">
                  <p className="font-semibold text-[11px] text-cyan-300 mb-0.5 flex items-center gap-1.5">
                    <span>Live Spoken Response</span>
                    {isListening && <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />}
                  </p>
                  <p className="leading-relaxed italic">
                    "{currentTranscript || 'Listening to your voice...'}"
                  </p>
                </div>
                <div className="w-6 h-6 rounded-lg bg-cyan-600/40 text-cyan-200 font-bold flex items-center justify-center shrink-0 text-[10px] border border-cyan-400/50">
                  You
                </div>
              </div>
            )}
          </div>
        )}

        <div ref={bottomRef} />
      </div>
    </div>
  );
};
