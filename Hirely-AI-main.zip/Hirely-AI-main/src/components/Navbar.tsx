import React from 'react';
import { Bot, Video, ArrowRight } from 'lucide-react';
import { InterviewPhase } from '../types';

interface NavbarProps {
  currentPhase: InterviewPhase;
  onNavigate: (phase: InterviewPhase) => void;
  onReset: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPhase, onNavigate, onReset }) => {
  return (
    <header className="sticky top-0 z-50 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 text-slate-100 px-4 lg:px-8 py-3.5 transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Brand logo & tagline */}
        <button 
          onClick={onReset}
          className="flex items-center gap-3 text-left group focus:outline-none focus:ring-2 focus:ring-indigo-500 rounded-lg p-1"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-indigo-500/20 group-hover:scale-105 transition-transform">
            <Bot className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-1.5 font-bold text-lg text-white tracking-tight">
              <span>Hirely AI</span>
              <span className="px-1.5 py-0.5 text-[10px] uppercase font-semibold tracking-wider bg-indigo-500/20 text-indigo-300 rounded border border-indigo-500/30">
                Voice AI
              </span>
            </div>
            <p className="text-xs text-slate-400 font-medium hidden sm:block">
              Your AI-Powered Interview Partner
            </p>
          </div>
        </button>

        {/* Navigation Links */}
        <nav className="flex items-center gap-2 sm:gap-4">
          <button
            onClick={() => onNavigate('landing')}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
              currentPhase === 'landing'
                ? 'bg-slate-800 text-indigo-400 border border-slate-700'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            Home
          </button>

          <button
            onClick={() => onNavigate('setup')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all shadow-sm ${
              currentPhase === 'interview'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 cursor-default'
                : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/20 hover:shadow-indigo-500/30'
            }`}
          >
            {currentPhase === 'interview' ? (
              <>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>Interview Live</span>
              </>
            ) : (
              <>
                <Video className="w-4 h-4" />
                <span>Practice Interview</span>
                <ArrowRight className="w-3.5 h-3.5 opacity-70" />
              </>
            )}
          </button>
        </nav>
      </div>
    </header>
  );
};
