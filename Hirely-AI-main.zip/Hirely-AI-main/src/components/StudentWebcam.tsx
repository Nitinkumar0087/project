import React, { useEffect, useRef, useState } from 'react';
import { Camera, CameraOff, Mic, MicOff, AlertCircle, RefreshCw, User } from 'lucide-react';

interface StudentWebcamProps {
  isListening: boolean;
  onMicToggle?: (enabled: boolean) => void;
}

export const StudentWebcam: React.FC<StudentWebcamProps> = ({ isListening, onMicToggle }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const [isVideoEnabled, setIsVideoEnabled] = useState<boolean>(true);
  const [isAudioEnabled, setIsAudioEnabled] = useState<boolean>(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isInitializing, setIsInitializing] = useState<boolean>(true);

  const setupCamera = async () => {
    setIsInitializing(true);
    setErrorMessage(null);

    // Stop existing stream
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: 'user' },
        audio: true,
      });

      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }

      setIsVideoEnabled(true);
      setIsAudioEnabled(true);
    } catch (err: any) {
      console.warn('Student webcam access error:', err);
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setErrorMessage('Camera or Microphone permission was denied. Click "Allow" in your browser address bar to enable webcam.');
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        setErrorMessage('No camera or microphone hardware detected on this device.');
      } else if (err.name === 'NotReadableError' || err.name === 'TrackStartError') {
        setErrorMessage('Your camera or microphone is already in use by another application.');
      } else {
        setErrorMessage(err.message || 'Unable to access your webcam or microphone.');
      }
    } finally {
      setIsInitializing(false);
    }
  };

  useEffect(() => {
    setupCamera();

    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  const toggleVideoTrack = () => {
    if (streamRef.current) {
      const videoTracks = streamRef.current.getVideoTracks();
      if (videoTracks.length > 0) {
        const nextState = !videoTracks[0].enabled;
        videoTracks[0].enabled = nextState;
        setIsVideoEnabled(nextState);
      }
    }
  };

  const toggleAudioTrack = () => {
    if (streamRef.current) {
      const audioTracks = streamRef.current.getAudioTracks();
      if (audioTracks.length > 0) {
        const nextState = !audioTracks[0].enabled;
        audioTracks[0].enabled = nextState;
        setIsAudioEnabled(nextState);
        if (onMicToggle) onMicToggle(nextState);
      }
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 md:p-6 flex flex-col justify-between h-full relative overflow-hidden shadow-xl">
      {/* Top Bar */}
      <div className="flex items-center justify-between mb-4 z-10">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
          <h3 className="text-sm font-bold text-white">Student Live Camera</h3>
        </div>

        <div className="flex items-center gap-2">
          <span
            className={`px-2.5 py-1 rounded-full text-[11px] font-semibold flex items-center gap-1 ${
              isListening
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 animate-pulse'
                : 'bg-slate-800 text-slate-400 border border-slate-700'
            }`}
          >
            <Mic className="w-3 h-3" />
            <span>{isListening ? 'Mic Active' : 'Mic Idle'}</span>
          </span>
        </div>
      </div>

      {/* Main Video Box */}
      <div className="relative aspect-video bg-slate-950 rounded-xl overflow-hidden border border-slate-800 flex items-center justify-center my-auto">
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className={`w-full h-full object-cover transform -scale-x-100 ${
            isVideoEnabled && !errorMessage ? 'block' : 'hidden'
          }`}
        />

        {/* Video Off Placeholder */}
        {(!isVideoEnabled || errorMessage) && (
          <div className="p-6 text-center space-y-3">
            <div className="w-16 h-16 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center mx-auto text-slate-500">
              <User className="w-8 h-8" />
            </div>
            <p className="text-xs text-slate-400 max-w-xs mx-auto">
              {errorMessage || 'Camera is toggled off.'}
            </p>
            {errorMessage && (
              <button
                onClick={setupCamera}
                disabled={isInitializing}
                className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold inline-flex items-center gap-1.5 transition-colors"
              >
                <RefreshCw className={`w-3 h-3 ${isInitializing ? 'animate-spin' : ''}`} />
                <span>Retry Device Access</span>
              </button>
            )}
          </div>
        )}

        {/* Floating Controls Overlay */}
        <div className="absolute bottom-3 right-3 flex items-center gap-2 z-20">
          <button
            onClick={toggleVideoTrack}
            className={`p-2 rounded-lg border transition-all ${
              isVideoEnabled
                ? 'bg-slate-900/80 hover:bg-slate-800 border-slate-700 text-slate-200'
                : 'bg-rose-500/80 border-rose-600 text-white'
            }`}
            title={isVideoEnabled ? 'Turn camera off' : 'Turn camera on'}
          >
            {isVideoEnabled ? <Camera className="w-4 h-4" /> : <CameraOff className="w-4 h-4" />}
          </button>

          <button
            onClick={toggleAudioTrack}
            className={`p-2 rounded-lg border transition-all ${
              isAudioEnabled
                ? 'bg-slate-900/80 hover:bg-slate-800 border-slate-700 text-slate-200'
                : 'bg-rose-500/80 border-rose-600 text-white'
            }`}
            title={isAudioEnabled ? 'Mute microphone' : 'Unmute microphone'}
          >
            {isAudioEnabled ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Footer Info */}
      <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400 z-10 mt-4">
        <span>Facial framing: Position face clearly</span>
        <span>Resolution: 720p HD</span>
      </div>
    </div>
  );
};
