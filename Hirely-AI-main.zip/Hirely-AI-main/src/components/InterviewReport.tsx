import React from 'react';
import { Award, CheckCircle2, AlertTriangle, ArrowRight, RotateCcw, Printer, Share2, Sparkles, Brain, MessageSquare, Target, Layers } from 'lucide-react';
import { FinalReport, InterviewConfig } from '../types';

interface InterviewReportProps {
  report: FinalReport;
  config: InterviewConfig;
  onRetake: () => void;
  onHome: () => void;
}

export const InterviewReport: React.FC<InterviewReportProps> = ({
  report,
  config,
  onRetake,
  onHome,
}) => {
  const roleName = config.role === 'Custom' && config.customRole ? config.customRole : config.role;

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10';
    if (score >= 60) return 'text-indigo-400 border-indigo-500/30 bg-indigo-500/10';
    return 'text-amber-400 border-amber-500/30 bg-amber-500/10';
  };

  const getBarColor = (score: number) => {
    if (score >= 80) return 'bg-emerald-500';
    if (score >= 60) return 'bg-indigo-500';
    return 'bg-amber-500';
  };

  const categories = [
    { label: 'Technical Knowledge', value: report.categoryScores.technicalKnowledge, icon: Brain },
    { label: 'Communication', value: report.categoryScores.communication, icon: MessageSquare },
    { label: 'Relevance', value: report.categoryScores.relevance, icon: Target },
    { label: 'Completeness', value: report.categoryScores.completeness, icon: CheckCircle2 },
    { label: 'Problem Solving', value: report.categoryScores.problemSolving, icon: Sparkles },
    { label: 'Answer Structure', value: report.categoryScores.answerStructure, icon: Layers },
  ];

  return (
    <div className="min-h-[calc(100vh-65px)] bg-slate-950 text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto space-y-8">
        {/* Top Header Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 relative overflow-hidden shadow-2xl">
          <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

          <div className="flex flex-col md:flex-row items-center justify-between gap-6 relative z-10">
            <div className="space-y-3 text-center md:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Interview Evaluation Completed</span>
              </div>
              <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
                Interview Performance Report
              </h1>
              <p className="text-slate-400 text-sm">
                Target Role: <strong className="text-white">{roleName}</strong> | Difficulty: <strong className="text-white">{config.difficulty}</strong>
              </p>
            </div>

            {/* Overall Score Badge Gauge */}
            <div className="flex flex-col items-center justify-center p-6 bg-slate-950/80 border border-slate-800 rounded-2xl shadow-inner min-w-[200px]">
              <span className="text-xs uppercase tracking-wider font-bold text-slate-400 mb-1">
                Overall Score
              </span>
              <div className="text-5xl font-black tracking-tight text-white flex items-baseline gap-1">
                <span className={report.overallScore >= 80 ? 'text-emerald-400' : 'text-indigo-400'}>
                  {report.overallScore}
                </span>
                <span className="text-xl text-slate-500 font-semibold">/100</span>
              </div>
              <span
                className={`mt-2 px-3 py-1 rounded-full text-xs font-bold border ${getScoreColor(
                  report.overallScore
                )}`}
              >
                {report.roleSuitability}
              </span>
            </div>
          </div>

          {/* Executive Summary Callout */}
          <div className="mt-6 pt-6 border-t border-slate-800 text-sm text-slate-300 leading-relaxed bg-slate-950/40 p-4 rounded-xl border-slate-800/60">
            <p className="font-semibold text-white mb-1">Executive Evaluation Summary:</p>
            <p>{report.overallFeedback}</p>
          </div>
        </div>

        {/* Category Breakdown & Strengths/Improvements (2 cols) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Category Scores */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5 shadow-xl">
            <h2 className="text-lg font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
              <Award className="w-5 h-5 text-indigo-400" />
              <span>Skill Category Breakdown</span>
            </h2>

            <div className="space-y-4">
              {categories.map((cat) => {
                const Icon = cat.icon;
                return (
                  <div key={cat.label} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
                      <span className="flex items-center gap-2">
                        <Icon className="w-3.5 h-3.5 text-indigo-400" />
                        <span>{cat.label}</span>
                      </span>
                      <span className="font-bold text-white">{cat.value}/100</span>
                    </div>

                    <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                      <div
                        className={`h-full rounded-full transition-all duration-1000 ${getBarColor(cat.value)}`}
                        style={{ width: `${cat.value}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Strengths & Areas to Improve */}
          <div className="space-y-6">
            {/* Strengths */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-3 shadow-xl">
              <h2 className="text-base font-bold text-emerald-400 flex items-center gap-2 border-b border-slate-800 pb-2.5">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                <span>Key Strengths</span>
              </h2>
              <ul className="space-y-2 text-xs sm:text-sm text-slate-300">
                {report.strengths.map((str, idx) => (
                  <li key={idx} className="flex items-start gap-2.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-2 shrink-0" />
                    <span>{str}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Areas to Improve */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-3 shadow-xl">
              <h2 className="text-base font-bold text-amber-400 flex items-center gap-2 border-b border-slate-800 pb-2.5">
                <AlertTriangle className="w-5 h-5 text-amber-400" />
                <span>Areas to Improve</span>
              </h2>
              <ul className="space-y-2 text-xs sm:text-sm text-slate-300">
                {report.areasToImprove.map((area, idx) => (
                  <li key={idx} className="flex items-start gap-2.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-2 shrink-0" />
                    <span>{area}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Question by Question Detailed Breakdown */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6 shadow-xl">
          <h2 className="text-lg font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
            <MessageSquare className="w-5 h-5 text-indigo-400" />
            <span>Question-by-Question Detailed Feedback</span>
          </h2>

          <div className="space-y-4">
            {report.questionSummaries.map((q) => (
              <div
                key={q.questionNumber}
                className="bg-slate-950 border border-slate-800 rounded-xl p-5 space-y-3 text-xs sm:text-sm"
              >
                <div className="flex items-center justify-between gap-4 pb-2 border-b border-slate-800/80">
                  <span className="font-bold text-indigo-300 text-sm">
                    Question {q.questionNumber}
                  </span>
                  <span className="px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 font-bold text-xs">
                    Score: {q.score}/10
                  </span>
                </div>

                <div>
                  <p className="font-semibold text-white mb-1">"{q.question}"</p>
                  <p className="text-slate-400 italic bg-slate-900/60 p-3 rounded-lg border border-slate-800">
                    Candidate Answer: "{q.candidateAnswer}"
                  </p>
                </div>

                <div className="pt-1 space-y-2">
                  <p className="text-slate-200">
                    <strong className="text-indigo-400">Feedback:</strong> {q.feedback}
                  </p>

                  {(q.keyStrengths || q.keyImprovements) && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1">
                      {q.keyStrengths && (
                        <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-emerald-300">
                          <strong>Strength:</strong> {q.keyStrengths}
                        </div>
                      )}
                      {q.keyImprovements && (
                        <div className="p-2 bg-amber-500/10 border border-amber-500/20 rounded-lg text-amber-300">
                          <strong>Improvement:</strong> {q.keyImprovements}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-800">
          <button
            onClick={() => window.print()}
            className="w-full sm:w-auto px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-sm flex items-center justify-center gap-2 transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>Print Report</span>
          </button>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              onClick={onHome}
              className="w-full sm:w-auto px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-sm transition-colors text-center"
            >
              Back to Home
            </button>

            <button
              onClick={onRetake}
              className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-cyan-500 hover:from-indigo-500 hover:to-cyan-400 text-white font-bold text-sm shadow-lg shadow-indigo-600/25 transition-all flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Practice Another Interview</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
