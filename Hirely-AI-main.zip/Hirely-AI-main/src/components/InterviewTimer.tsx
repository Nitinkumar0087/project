import React, { useEffect, useState } from 'react';
import { Clock, HelpCircle, Gauge } from 'lucide-react';
import { InterviewDifficulty } from '../types';

interface InterviewTimerProps {
  durationMinutes: number;
  currentQuestionIndex: number;
  totalQuestions: number;
  difficulty: InterviewDifficulty;
  onTimeExpired?: () => void;
}

export const InterviewTimer: React.FC<InterviewTimerProps> = ({
  durationMinutes,
  currentQuestionIndex,
  totalQuestions,
  difficulty,
  onTimeExpired,
}) => {
  const [secondsRemaining, setSecondsRemaining] = useState<number>(durationMinutes * 60);

  useEffect(() => {
    const interval = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          if (onTimeExpired) onTimeExpired();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [durationMinutes, onTimeExpired]);

  const minutes = Math.floor(secondsRemaining / 60);
  const seconds = secondsRemaining % 60;
  const isUrgent = secondsRemaining < 120; // less than 2 mins

  const getDifficultyBadge = () => {
    switch (difficulty) {
      case 'Easy':
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
      case 'Medium':
        return 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30';
      case 'Hard':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/30';
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5 flex items-center justify-between text-xs text-slate-300">
      {/* Timer */}
      <div className="flex items-center gap-2">
        <Clock className={`w-4 h-4 ${isUrgent ? 'text-rose-400 animate-pulse' : 'text-indigo-400'}`} />
        <span className="font-medium text-slate-400">Time:</span>
        <span
          className={`font-mono font-bold text-sm ${
            isUrgent ? 'text-rose-400 animate-pulse' : 'text-white'
          }`}
        >
          {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
        </span>
      </div>

      {/* Question Index */}
      <div className="flex items-center gap-1.5 font-semibold text-slate-200">
        <HelpCircle className="w-3.5 h-3.5 text-indigo-400" />
        <span>
          Question <strong className="text-white">{currentQuestionIndex}</strong> of{' '}
          <strong className="text-white">{totalQuestions}</strong>
        </span>
      </div>

      {/* Adaptive Difficulty Badge */}
      <div className="flex items-center gap-1.5">
        <Gauge className="w-3.5 h-3.5 text-slate-400" />
        <span
          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider border ${getDifficultyBadge()}`}
        >
          {difficulty} Mode
        </span>
      </div>
    </div>
  );
};
