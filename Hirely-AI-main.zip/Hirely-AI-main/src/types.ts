export type InterviewRole = 
  | 'Software Developer' 
  | 'Data Analyst' 
  | 'AI/ML Engineer' 
  | 'HR' 
  | 'Custom';

export type InterviewDifficulty = 'Easy' | 'Medium' | 'Hard';

export interface InterviewConfig {
  role: InterviewRole;
  customRole?: string;
  difficulty: InterviewDifficulty;
  durationMinutes: number;
  totalQuestions: number;
  selectedCandidateId?: string;
}

export interface Mission {
  day: number;
  topic: string;
  attempts?: number;
  status?: 'completed' | 'failed' | 'skipped';
  lastError?: string;
}

export interface Candidate {
  id: string;
  name: string;
  jobRole: string;
  yearsExperience: number;
  education: string;
  commitDays: number;
  missionsCompleted: number;
  missionsFirstTry: number;
  capstoneProject?: string;
  completedMissions: Mission[];
  failedMissions: Mission[];
  skippedMissions: Mission[];
}

export interface CurriculumDay {
  day: number;
  topic: string;
  learningObjectives: string[];
  tools: string[];
}

export interface CurriculumModule {
  id: number;
  name: string;
  days: CurriculumDay[];
}

export interface Curriculum {
  cohort: string;
  modules: CurriculumModule[];
}

export interface Feedback {
  summary: string;
  strengths: string[];
  gaps: string[];
  next: string[];
  confidenceLevel?: 'High' | 'Medium' | 'Low';
  evidenceSummary?: string;
}

export interface InterviewRequest {
  sessionId: string;
  candidate?: Candidate;
  message?: string;
}

export interface InterviewResponse {
  reply: string;
  done: boolean;
  feedback?: Feedback;
  report?: FinalReport;
}

export interface SessionState {
  sessionId: string;
  candidate: Candidate;
  questionsAsked: number;
  curriculumDaysCovered: number[];
  topicsCovered: string[];
  conversationHistory: Array<{
    role: 'interviewer' | 'candidate';
    content: string;
    dayNumber?: number;
    topic?: string;
    wasUncertain?: boolean;
  }>;
  currentTopic?: string;
  currentDayNumber?: number;
  difficulty: InterviewDifficulty;
  followUpCount: number;
  scoreSignals: {
    totalTechnicalScore: number;
    totalCommunicationScore: number;
    evaluationsCount: number;
  };
  interviewComplete: boolean;
  finalFeedback?: Feedback;
  finalReport?: FinalReport;
}

export interface QuestionItem {
  id: string;
  index: number;
  questionText: string;
  interviewerNote?: string;
  expectedKeyPoints?: string[];
  isFollowUp?: boolean;
  curriculumDay?: number;
}

export interface AnswerEvaluation {
  technicalAccuracy: number; // 0-10
  relevance: number; // 0-10
  completeness: number; // 0-10
  clarity: number; // 0-10
  communication: number; // 0-10
  reasoning: number; // 0-10
  overall: number; // 0-10
  feedbackSummary: string;
  strengths: string[];
  areasToImprove: string[];
  recommendedFollowUpType?: 'clarification' | 'deeper' | 'easier' | 'next_topic';
  adjustedDifficulty?: InterviewDifficulty;
}

export interface InterviewQAPair {
  question: QuestionItem;
  candidateAnswer: string;
  evaluation?: AnswerEvaluation;
  timestamp: number;
}

export interface QuestionSummaryReport {
  questionNumber: number;
  question: string;
  candidateAnswer: string;
  score: number; // 0-10
  feedback: string;
  keyStrengths?: string;
  keyImprovements?: string;
}

export interface FinalReport {
  overallScore: number; // 0-100
  categoryScores: {
    technicalKnowledge: number;
    communication: number;
    relevance: number;
    completeness: number;
    problemSolving: number;
    answerStructure: number;
  };
  strengths: string[];
  areasToImprove: string[];
  overallFeedback: string;
  roleSuitability: string;
  questionSummaries: QuestionSummaryReport[];
  confidenceLevel?: 'High' | 'Medium' | 'Low';
  evidenceSummary?: string;
  categoryEvidence?: {
    technicalKnowledge?: string;
    communication?: string;
    relevance?: string;
    completeness?: string;
    problemSolving?: string;
    answerStructure?: string;
  };
}

export type InterviewPhase = 
  | 'landing' 
  | 'setup' 
  | 'interview' 
  | 'report';

export type AIStatus = 'idle' | 'introducing' | 'speaking' | 'listening' | 'evaluating' | 'completed';

