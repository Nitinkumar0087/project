import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { generateInitialQuestion, generateNextQuestion } from './lib/ai/interviewer.js';
import { evaluateAnswer, generateFinalReport } from './lib/ai/evaluator.js';
import { handleCohortInterviewRequest, getCandidatesData } from './lib/ai/cohortInterviewEngine.js';
import { InterviewConfig, InterviewQAPair, QuestionItem, InterviewDifficulty } from './src/types.js';

dotenv.config();

export const app = express();

app.use(express.json());

// CORS headers
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }
  next();
});

// Health check endpoint
app.get(['/api/health', '/health'], (req, res) => {
  res.json({ status: 'ok', app: 'Hirely AI' });
});

// Get Candidates endpoint
app.get(['/api/candidates', '/candidates'], (req, res) => {
  try {
    const candidates = getCandidatesData();
    res.json(candidates);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to load candidates.' });
  }
});

// Direct download endpoint for project ZIP
app.get(['/api/download-zip', '/download-zip', '/Hirely-AI-source-code.zip'], (req, res) => {
  const zipPath = path.join(process.cwd(), 'Hirely-AI-source-code.zip');
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', 'attachment; filename="Hirely-AI-source-code.zip"');
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  res.sendFile(zipPath, (err) => {
    if (err && !res.headersSent) {
      console.error('Error downloading zip:', err);
      res.status(500).send('ZIP file not found.');
    }
  });
});

// Official Hackathon POST /api/interview Endpoint
app.post(['/api/interview', '/interview'], async (req, res) => {
  try {
    const { sessionId, candidate, message, userMessage } = req.body || {};
    const clientMsg = message ?? userMessage;

    if (!sessionId) {
      return res.status(400).json({ error: 'sessionId is required.' });
    }

    const result = await handleCohortInterviewRequest(sessionId, candidate, clientMsg);
    return res.json(result);
  } catch (err: any) {
    console.error('Error handling POST /api/interview:', err);
    return res.status(500).json({
      reply: 'An error occurred processing your request.',
      done: false,
      error: err.message || 'Internal server error',
    });
  }
});

// 1. Start Interview Endpoint (Compatibility Wrapper)
app.post(['/api/interview/start', '/interview/start'], async (req, res) => {
  try {
    const config: InterviewConfig = req.body?.config;
    if (!config) {
      return res.status(400).json({ error: 'Interview configuration is required.' });
    }

    const result = await generateInitialQuestion(config);
    return res.json(result);
  } catch (err: any) {
    console.error('Error starting interview:', err);
    return res.status(500).json({ error: err.message || 'Failed to start interview.' });
  }
});

// 2. Evaluate Candidate Answer and Generate Next Question
app.post(['/api/interview/evaluate-and-next', '/interview/evaluate-and-next'], async (req, res) => {
  try {
    const {
      config,
      question,
      candidateAnswer,
      history,
      currentDifficulty,
    }: {
      config: InterviewConfig;
      question: QuestionItem;
      candidateAnswer: string;
      history: InterviewQAPair[];
      currentDifficulty: InterviewDifficulty;
    } = req.body || {};

    if (!config || !question) {
      return res.status(400).json({ error: 'Config and current question are required.' });
    }

    const evaluation = await evaluateAnswer(config, question, candidateAnswer || '');

    const newQaPair: InterviewQAPair = {
      question,
      candidateAnswer: candidateAnswer || '',
      evaluation,
      timestamp: Date.now(),
    };

    const updatedHistory = [...(history || []), newQaPair];

    const totalQuestions = config.totalQuestions || 5;
    if (updatedHistory.length >= totalQuestions) {
      return res.json({
        evaluation,
        isCompleted: true,
        updatedHistory,
        completionMessage: 'Thank you for answering all questions! Generating your final interview report now.',
      });
    }

    const nextResult = await generateNextQuestion(config, updatedHistory, currentDifficulty || config.difficulty);

    return res.json({
      evaluation,
      isCompleted: false,
      nextQuestion: nextResult.question,
      nextDifficulty: nextResult.nextDifficulty,
      transitionMessage: nextResult.transitionMessage,
      updatedHistory,
    });
  } catch (err: any) {
    console.error('Error processing answer and next question:', err);
    return res.status(500).json({ error: err.message || 'Failed to process interview response.' });
  }
});

// 3. Generate Final Report Endpoint
app.post(['/api/interview/report', '/interview/report'], async (req, res) => {
  try {
    const { config, history }: { config: InterviewConfig; history: InterviewQAPair[] } = req.body || {};
    if (!config || !history) {
      return res.status(400).json({ error: 'Config and interview history are required.' });
    }

    const report = await generateFinalReport(config, history);
    return res.json({ report });
  } catch (err: any) {
    console.error('Error generating report:', err);
    return res.status(500).json({ error: err.message || 'Failed to generate report.' });
  }
});

async function startServer() {
  const PORT = 3000;

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Hirely AI server running on http://0.0.0.0:${PORT}`);
  });
}

if (!process.env.VERCEL) {
  startServer();
}

export default app;
