/**
 * AarogyaMitra AI — Health Assistant Brain
 * Central logic for doctor-like conversation flow, emergency detection,
 * suggested replies parsing, and cross-module integration actions.
 */

// ─────────────────────────────────────────────────────────────────────────────
// EMERGENCY DETECTION
// ─────────────────────────────────────────────────────────────────────────────

interface EmergencyResult {
  isEmergency: boolean;
  responseEn: string | null;
  responseHi: string | null;
}

const EMERGENCY_PATTERNS: Array<{
  patterns: string[];
  en: string;
  hi: string;
}> = [
  {
    patterns: [
      "chest pain", "seene me dard", "seene mein dard", "heart attack", "dil ka daura",
      "angina", "left chest pain", "dil me dard",
      "सीने में दर्द", "हार्ट अटैक", "दिल का दौरा", "छाती में दर्द",
    ],
    en: `🚨 EMERGENCY — Possible Heart Emergency

Call 112 or 108 immediately!

While waiting for help:
✅ Sit the person down — do NOT let them walk
✅ Loosen tight clothing around chest and neck
✅ If conscious and not allergic, give 1 Aspirin (325mg) to chew
❌ Do NOT give food or water
❌ Do NOT leave them alone

National Emergency: 112 | Ambulance: 108`,
    hi: `🚨 आपातकाल — संभावित हृदय आपातकाल

तुरंत 112 या 108 पर कॉल करें!

मदद आने तक:
✅ व्यक्ति को बैठाएं — चलने न दें
✅ छाती और गर्दन के तंग कपड़े ढीले करें
✅ अगर होश में हो और एलर्जी न हो तो 1 Aspirin (325mg) चबाने दें
❌ खाना या पानी न दें
❌ अकेला न छोड़ें

राष्ट्रीय आपातकाल: 112 | एम्बुलेंस: 108`,
  },
  {
    patterns: [
      "can't breathe", "cannot breathe", "saas nahi aa rahi", "breathless", "suffocating",
      "ghut raha", "breathing stopped", "saans band",
      "shortness of breath", "saans ki taklif", "saans lene mein", "saans lene me",
      "सांस लेने में", "सांस नहीं आ रही", "सांस फूलना", "सांस की तकलीफ",
    ],
    en: `🚨 EMERGENCY — Breathing Difficulty

Call 112 / 108 immediately!

While waiting:
✅ Keep person upright or sitting — DO NOT lay them flat
✅ Loosen any tight clothing around neck and chest
✅ Move to fresh air if possible
✅ If they have an inhaler — use it now (2-4 puffs)
❌ Do NOT give food or water

National Emergency: 112 | Ambulance: 108`,
    hi: `🚨 आपातकाल — सांस लेने में कठिनाई

तुरंत 112 / 108 पर कॉल करें!

मदद आने तक:
✅ व्यक्ति को सीधे बैठाएं — लेटाएं नहीं
✅ गर्दन और छाती के तंग कपड़े ढीले करें
✅ हो सके तो ताज़ी हवा में ले जाएं
✅ अगर इनहेलर है — अभी उपयोग करें (2-4 पफ)
❌ खाना या पानी न दें

राष्ट्रीय आपातकाल: 112 | एम्बुलेंस: 108`,
  },
  {
    patterns: [
      "snake bite", "sanp ne kaata", "saanp ne kaata",
      "snake poison", "saap ka zeher",
    ],
    en: `🚨 EMERGENCY — Snake Bite

Call 112 / 108 immediately!

✅ Keep the person STILL and CALM — movement spreads venom faster
✅ Keep the bitten limb BELOW heart level
✅ Remove rings, watches, tight clothing near the bite
❌ DO NOT cut or suck the bite wound
❌ DO NOT apply tourniquet or ice

Rush to nearest Government Hospital — anti-venom is ONLY available there!
National Emergency: 112 | Ambulance: 108`,
    hi: `🚨 आपातकाल — सांप का काटना

तुरंत 112 / 108 पर कॉल करें!

✅ व्यक्ति को स्थिर और शांत रखें — हिलने से ज़हर तेज़ी से फैलता है
✅ काटे गए अंग को दिल के स्तर से नीचे रखें
✅ काट के पास की अंगूठी, घड़ी, तंग कपड़े हटाएं
❌ काटे को काटें या चूसें नहीं
❌ टूर्निकेट या बर्फ न लगाएं

तुरंत निकटतम सरकारी अस्पताल जाएं — एंटी-वेनम केवल वहीं मिलता है!
राष्ट्रीय आपातकाल: 112 | एम्बुलेंस: 108`,
  },
  {
    patterns: [
      "unconscious", "behosh", "faint", "murcha",
      "not responding", "coma",
    ],
    en: `🚨 EMERGENCY — Person Unconscious / Not Responding

Call 112 / 108 immediately!

✅ Check if person is breathing — watch chest rise
✅ Place in recovery position (on side) if breathing
✅ If NOT breathing — start CPR if you know how
✅ Loosen tight clothing
❌ Do NOT give anything by mouth

National Emergency: 112 | Ambulance: 108`,
    hi: `🚨 आपातकाल — व्यक्ति बेहोश / कोई प्रतिक्रिया नहीं

तुरंत 112 / 108 पर कॉल करें!

✅ जांचें कि व्यक्ति सांस ले रहा है — छाती का उठना देखें
✅ अगर सांस आ रही है तो करवट से लेटाएं
✅ अगर सांस नहीं आ रही — CPR जानते हों तो शुरू करें
✅ तंग कपड़े ढीले करें
❌ मुंह से कुछ न दें

राष्ट्रीय आपातकाल: 112 | एम्बुलेंस: 108`,
  },
  {
    patterns: [
      "heavy bleeding", "bahut khoon", "blood not stopping",
      "khoon nahi ruk raha", "spurting blood",
    ],
    en: `🚨 EMERGENCY — Severe Bleeding

Call 112 / 108 immediately!

✅ Apply FIRM, DIRECT pressure with a clean cloth — do NOT remove it
✅ If bleeding is on a limb — elevate above heart level
✅ Keep applying pressure — add more cloth on top if soaked through
❌ Do NOT remove embedded objects from wounds

National Emergency: 112 | Ambulance: 108`,
    hi: `🚨 आपातकाल — अत्यधिक रक्तस्राव

तुरंत 112 / 108 पर कॉल करें!

✅ साफ कपड़े से मज़बूत, सीधा दबाव डालें — कपड़ा न हटाएं
✅ अगर अंग पर है तो दिल से ऊपर उठाएं
✅ दबाव बनाए रखें — खून निकले तो ऊपर और कपड़ा रखें
❌ घाव से फंसी चीज़ें न निकालें

राष्ट्रीय आपातकाल: 112 | एम्बुलेंस: 108`,
  },
  {
    patterns: [
      "stroke", "paralysis", "laqwa", "face drooping",
      "chehra tircha", "sudden arm weakness", "speech difficulty",
    ],
    en: `🚨 EMERGENCY — Possible Stroke (Brain Attack)

Use the FAST test:
🔴 Face — Is one side drooping?
🔴 Arms — Can they raise both arms equally?
🔴 Speech — Is speech slurred or confused?
🔴 Time — Call 112 / 108 NOW!

✅ Keep person lying down with head slightly elevated
✅ Note the exact time symptoms started
❌ Do NOT give food, water, or medicines

National Emergency: 112 | Ambulance: 108`,
    hi: `🚨 आपातकाल — संभावित स्ट्रोक (दिमागी दौरा)

FAST टेस्ट करें:
🔴 Face (चेहरा) — क्या एक तरफ झुक रहा है?
🔴 Arms (बांहें) — क्या दोनों बांहें समान रूप से उठा सकते हैं?
🔴 Speech (बोलना) — क्या बोलना लड़खड़ा रहा है?
🔴 Time (समय) — अभी 112 / 108 पर कॉल करें!

✅ व्यक्ति को सिर थोड़ा ऊंचा करके लेटाएं
✅ लक्षण शुरू होने का सटीक समय नोट करें
❌ खाना, पानी या दवाई न दें

राष्ट्रीय आपातकाल: 112 | एम्बुलेंस: 108`,
  },
  {
    patterns: [
      "labour pain", "prasav peeda", "water broke",
      "paani toot gaya", "bleeding pregnancy",
    ],
    en: `🚨 EMERGENCY — Pregnancy Emergency

Call 112 / 108 immediately!

✅ Help the mother lie on her left side — this improves blood flow to baby
✅ Keep her calm and breathing slowly
✅ If water has broken, note the time
❌ Do NOT give food or water if going to hospital

Go to nearest hospital with maternity ward immediately!
National Emergency: 112 | Ambulance: 108 | Janani Shishu Suraksha: 104`,
    hi: `🚨 आपातकाल — गर्भावस्था आपातकाल

तुरंत 112 / 108 पर कॉल करें!

✅ माँ को बाईं तरफ करवट से लेटाएं — इससे बच्चे को रक्त प्रवाह बेहतर होता है
✅ शांत रखें और धीरे सांस लेने में मदद करें
✅ अगर पानी टूटा हो तो समय नोट करें
❌ अस्पताल जाना हो तो खाना या पानी न दें

तुरंत निकटतम प्रसूति वार्ड वाले अस्पताल जाएं!
राष्ट्रीय आपातकाल: 112 | एम्बुलेंस: 108 | जननी शिशु सुरक्षा: 104`,
  },
  {
    patterns: [
      "medical emergency", "emergency hai", "emergency help", "in an emergency",
      "emergency kya hai", "emergency mein kya kare", "emergency situation",
      "emergency", "urgency", "urgent help",
      "आपातकाल", "एमरजेंसी", "इमरजेंसी", "आपात स्थिति",
    ],
    en: `🚨 MEDICAL EMERGENCY ASSISTANCE

Call 112 or 108 immediately for urgent medical help!

Key Steps in any Medical Emergency:
✅ Stay calm and ensure the scene is safe
✅ Call National Emergency (112) or Ambulance (108)
✅ Keep the patient still and comfortable
✅ Do NOT give food or water if unconscious or severely injured
✅ Follow dispatcher instructions until medical professionals arrive

National Emergency: 112 | Ambulance: 108 | Medical Helpline: 104`,
    hi: `🚨 चिकित्सा आपातकालीन सहायता

आपातकालीन चिकित्सा सहायता के लिए तुरंत 112 या 108 पर कॉल करें!

किसी भी आपात स्थिति में मुख्य कदम:
✅ शांत रहें और आसपास की सुरक्षा जांचें
✅ राष्ट्रीय आपातकाल (112) या एम्बुलेंस (108) पर कॉल करें
✅ मरीज को शांत और आरामदायक स्थिति में रखें
✅ बेहोश या गंभीर घायल व्यक्ति को खाना या पानी न दें
✅ मेडिकल टीम आने तक निर्देशों का पालन करें

राष्ट्रीय आपातकाल: 112 | एम्बुलेंस: 108 | मेडिकल हेल्पलाइन: 104`,
  },
];



export function detectEmergency(text: string): EmergencyResult {
  const normalized = text.toLowerCase().trim();

  for (const template of EMERGENCY_PATTERNS) {
    for (const pattern of template.patterns) {
      if (normalized.includes(pattern.toLowerCase())) {
        return {
          isEmergency: true,
          responseEn: template.en,
          responseHi: template.hi,
        };
      }
    }
  }

  return {
    isEmergency: false,
    responseEn: null,
    responseHi: null,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// DOCTOR CONVERSATION SYSTEM PROMPT
// ─────────────────────────────────────────────────────────────────────────────

export function buildDoctorSystemPrompt(
  language: string,
  userContext: string,
  reportContext?: string,
  medicalKnowledgeContext?: string,
  personalHealthContext?: string
): string {
  const targetLangName = language === "hi" ? "Hindi" : "English";

  const reportSection = reportContext
    ? `\n\nMEDICAL REPORT ANALYSIS (from scanner):\nThe user just had a medical report analyzed. Here are the results:\n${reportContext}\n\nThe user is now asking about these results. Explain the findings in simple language and start a doctor-like conversation about their health based on this report.`
    : "";

  const personalSection = personalHealthContext && personalHealthContext.trim()
    ? `\n${personalHealthContext}\n`
    : (userContext && userContext.trim() ? `\nPATIENT CONTEXT:\n${userContext}\n` : "");

  return `You are AarogyaMitra AI, an expert Indian healthcare assistant behaving as a clinical physician.

LANGUAGE MANDATE:
- Target Language: ${targetLangName}.
- Respond strictly and naturally in ${targetLangName}.${language === "hi" ? " Use Devanagari script (हिंदी लिपि) for entire response." : ""}

DOCTOR PROTOCOL (PHASE 3):
- Phase 1 (Intake): On new symptoms, show empathy, explain symptoms have multiple causes (never give definitive single diagnosis), ask 1-2 focused follow-up questions (duration, severity, red flags).
- Phase 2 (Assessment): When assessing, structure cleanly: (1) Understanding & Potential Causes, (2) Monitoring & Safe Self-Care (hydration, rest, OTC ORS/Paracetamol), (3) Warning Signs (Red Flags), (4) When to Consult a Physician, (5) Guiding Next Step.
- Tone: Empathic, professional, concise (use bullets/short paragraphs). Never present unsupported diagnosis as fact.

HEALTH RECORD & PROFILE INQUIRIES:
- If user asks about their own registered profile, active medicines, appointments, daily logs, or reports: directly answer using factual personal health context below. Do NOT initiate symptom intake or ask redundant questions for simple record lookups. State clearly if no data is registered.

CLINICAL & SAFETY RULES:
- Use factual patient context. Never invent missing data, test results, appointments, or reference ranges.
- NEVER prescribe prescription-only medications, change dosages, or advise stopping prescribed drugs. You may mention standard OTC options (ORS, Paracetamol).
- Never claim a metric is "normal for your age" unless specific age is provided.
- If suicidal ideation occurs, immediately provide national helpline numbers (KIRAN: 1800-599-0019, Tele-MANAS: 14416).

MEDICAL REPORT RULES:
- Use only uploaded report data. Label facts vs clinical interpretations. Never invent parameters or reference ranges.

REAL ACTIONS:
- Appointment Booking: [BOOK_APPOINTMENT]{"doctorName":"...","date":"YYYY-MM-DD","time":"HH:MM"}[/BOOK_APPOINTMENT] (today is ${new Date().toISOString().split('T')[0]}). Use tentative wording.
- Hospital Finder: [FIND_HOSPITAL]{}[/FIND_HOSPITAL].

SUGGESTED REPLIES (MANDATORY FORMAT):
- End EVERY response with: [SUGGESTED_REPLIES]option 1|option 2|option 3[/SUGGESTED_REPLIES] (2-4 concise options, max 5 words each).
${personalSection}${reportSection}
${medicalKnowledgeContext ? `GENERAL MEDICAL KNOWLEDGE (TRUSTED REFERENCE):
${medicalKnowledgeContext}

GUIDELINE USAGE RULES:
1. Ground general health answers strictly in the GENERAL MEDICAL KNOWLEDGE context.
2. If guideline is absent, state that authoritative reference is unavailable and recommend consulting a physician.
3. Treat retrieved guidelines as educational reference material.` : ""}`;
}

// ─────────────────────────────────────────────────────────────────────────────
// SUGGESTED REPLIES PARSER
// ─────────────────────────────────────────────────────────────────────────────

export function parseSuggestedReplies(text: string): {
  cleanText: string;
  suggestions: string[];
} {
  // Strip any reasoning tags if present
  const sanitized = text
    .replace(/<think>[\s\S]*?<\/think>/gi, "")
    .replace(/<thinking>[\s\S]*?<\/thinking>/gi, "")
    .trim();

  const match = sanitized.match(
    /\[SUGGESTED_REPLIES\]([\s\S]*?)(?:\[\/SUGGESTED_REPLIES\]|$)/
  );

  if (!match) {
    return { cleanText: sanitized, suggestions: [] };
  }

  const suggestionsRaw = match[1].trim();
  const suggestions = suggestionsRaw
    .split(/\r?\n|\|/)
    .map((s) => s.replace(/^[•\-\d\.]+\s*/, "").trim())
    .filter((s) => s.length > 0)
    .slice(0, 4);

  const cleanText = sanitized.replace(
    /\[SUGGESTED_REPLIES\][\s\S]*?(?:\[\/SUGGESTED_REPLIES\]|$)/,
    ""
  ).trim();

  return { cleanText, suggestions };
}

// ─────────────────────────────────────────────────────────────────────────────
// CROSS-MODULE INTEGRATION ACTIONS
// ─────────────────────────────────────────────────────────────────────────────

export interface IntegrationAction {
  label: string;
  link: string;
  icon: string; // icon name key for lucide-react
}

export function getIntegrationActions(text: string): IntegrationAction[] {
  const lower = text.toLowerCase();
  const actions: IntegrationAction[] = [];

  // Hospital / emergency
  if (
    lower.includes("hospital") ||
    lower.includes("emergency") ||
    lower.includes("112") ||
    lower.includes("ambulance") ||
    lower.includes("अस्पताल") ||
    lower.includes("आपातकाल")
  ) {
    actions.push({
      label: "Find Hospital",
      link: "/hospital",
      icon: "hospital",
    });
  }

  // Specialist / appointment
  if (
    lower.includes("specialist") ||
    lower.includes("doctor") ||
    lower.includes("consult") ||
    lower.includes("appointment") ||
    lower.includes("डॉक्टर") ||
    lower.includes("विशेषज्ञ")
  ) {
    actions.push({
      label: "Book Appointment",
      link: "/appointments",
      icon: "calendar",
    });
  }

  // Medicine
  if (
    lower.includes("medicine") ||
    lower.includes("medication") ||
    lower.includes("tablet") ||
    lower.includes("dose") ||
    lower.includes("दवाई") ||
    lower.includes("दवा") ||
    lower.includes("गोली")
  ) {
    actions.push({
      label: "Add Medicine",
      link: "/medicines",
      icon: "pill",
    });
  }

  // Diet / nutrition
  if (
    lower.includes("diet") ||
    lower.includes("nutrition") ||
    lower.includes("food") ||
    lower.includes("eat") ||
    lower.includes("आहार") ||
    lower.includes("खाना")
  ) {
    // No direct page, but could save or show more — link to chat itself
    actions.push({
      label: "Diet Details",
      link: "/chat",
      icon: "apple",
    });
  }

  // Report / scan
  if (
    lower.includes("report") ||
    lower.includes("lab") ||
    lower.includes("test") ||
    lower.includes("scan") ||
    lower.includes("रिपोर्ट") ||
    lower.includes("जांच")
  ) {
    actions.push({
      label: "Scan Report",
      link: "/report-analyzer",
      icon: "file",
    });
  }

  // Government schemes
  if (
    lower.includes("scheme") ||
    lower.includes("ayushman") ||
    lower.includes("jan aushadhi") ||
    lower.includes("government") ||
    lower.includes("योजना") ||
    lower.includes("सरकारी")
  ) {
    actions.push({
      label: "Check Schemes",
      link: "/schemes",
      icon: "shield",
    });
  }

  // Always add these two if not already present
  if (!actions.some((a) => a.link === "/hospital")) {
    actions.push({
      label: "Find Hospital",
      link: "/hospital",
      icon: "hospital",
    });
  }
  if (!actions.some((a) => a.link === "/report-analyzer")) {
    actions.push({
      label: "Scan Report",
      link: "/report-analyzer",
      icon: "file",
    });
  }

  // Limit to 4 actions
  return actions.slice(0, 4);
}
